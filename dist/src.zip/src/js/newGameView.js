NewGameView = Framework.BaseView.extend({
    template: 'templates/NewGameView.html',

    events: {
        'change input[name=\'difficulty\']': 'onInputChange',
        'click #setDifficulty': 'onSetDifficulty',
    },

    loadingTemplate: 'common/templates/Loading.html',

    onSetDifficulty: function() {
        localStorage.difficulty = this.$('input[name="difficulty"]:checked').val();
        localStorage.scores = localStorage.difficulty == "untimed" ? "[3,3,3,3]" : "[]";
        localStorage.campaign = Campaign.generateCampaign(localStorage.difficulty);
        this.setParameters({
            mv : 'levelsView'
        })
    },
    onInputChange: function() {
        var difficulty = this.$('input[name="difficulty"]:checked').val();
        this.$('.desc').addClass('hide');
        this.$('#desc' + difficulty).removeClass('hide');
    },
    render: function() {
        this.onInputChange();
    }
});

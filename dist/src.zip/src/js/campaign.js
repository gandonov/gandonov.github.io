var Campaign = {

    modifiers: {
        easy: {
            holes: {
                initial: 20,
                magnifier: 1.2
            },
            length: {
                initial: 10,
                magnifier: 2
            },
            fixed: {
                initial: 4,
                magnifier: .5
            },
            time: {
                initial: 40,
                magnifier: 2.0
            }
        },
        medium: {
            holes: {
                initial: 18,
                magnifier: 1.2
            },
            length: {
                initial: 10,
                magnifier: 1.8
            },
            fixed: {
                initial: 6,
                magnifier: .444444
            },
            time: {
                initial: 35,
                magnifier: 1.95
            }
        },
        hard: {
            holes: {
                initial: 20,
                magnifier: 1.3
            },
            length: {
                initial: 9,
                magnifier: 2
            },
            fixed: {
                initial: 5,
                magnifier: .333333
            },
            time: {
                initial: 30,
                magnifier: 1.8
            }
        },
        inhuman: {
            holes: {
                initial: 20,
                magnifier: 1.2
            },
            length: {
                initial: 8,
                magnifier: 2
            },
            fixed: {
                initial: 4,
                magnifier: .222222
            },
            time: {
                initial: 25,
                magnifier: 1.7
            }
        },
    },

    untimed: [{
        "unlock": 0,
        "name": "short",
        "bonuses": ["SHIT", "h/1", "shit"],
        "boards": [{
            "dynamic": "10|1|0"
        }]
    }, {
        "unlock": 0,
        "name": "medium",
        "bonuses": ["SHIT", "h/2", "shit"],
        "boards": [{
            "dynamic": "15|3|3"
        }]
    }, {
        "unlock": 0,
        "name": "long",
        "bonuses": ["SHIT", "h/4", "shit"],
        "boards": [{
            "dynamic": "20|4|6"
        }]
    }, {
        "unlock": 0,
        "name": "very long",
        "bonuses": ["SHIT", "h/10", "shit"],
        "boards": [{
            "dynamic": "33|6|5"
        }]
    }],

    generateCampaign: function(difficulty) {
        if (difficulty == 'untimed') {
            return JSON.stringify(this.untimed);
        }
        var difficulty = difficulty || 'medium';
        var modifiers = this.modifiers[difficulty];
        var campaign = [];
        var unlock = 0;
        var totalLevels = 10;
        var generatePuzzle = function(level) {
            var holes = modifiers.holes.initial - Math.floor(level * modifiers.holes.magnifier);
            var length = modifiers.length.initial + Math.floor(level * modifiers.length.magnifier);
            var fixed = modifiers.fixed.initial + Math.ceil(level * modifiers.fixed.magnifier);
            var time = modifiers.time.initial + Math.ceil(level * modifiers.time.magnifier);
            return {
                "time": time,
                "dynamic": length + "|" + fixed + "|" + holes
            }
        }
        for (var i = 0; i < totalLevels; i++) {
            var level = {};
            level.unlock = unlock;
            level.bonuses = [];
            var combos = ["lt", "et", "h/3", "h/4", "h/5"];

            level.bonuses.push("SHIT");
            level.bonuses.push(combos.splice(Math.floor(Math.random() * combos.length), 1)[0]);
            level.bonuses.push(combos.splice(Math.floor(Math.random() * combos.length), 1)[0]);

            level.boards = [];
            var bl = 7 - Math.floor(i / 2);
            for (var j = 0; j < bl; j++) {
                level.boards.push(generatePuzzle(i));
            }
            var random = Math.random();
            if (random > .68) {
                unlock += 3;
            } else if (random > .32) {
                unlock += 2;
            } else {
                unlock += 1;
            }
            campaign.push(level);
        }
        return JSON.stringify(campaign);
    }
}

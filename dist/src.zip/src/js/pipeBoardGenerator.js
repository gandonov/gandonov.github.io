/**
 * Basic priority queue implementation. If a better priority queue is wanted/needed,
 * this code works with the implementation in google's closure library (https://code.google.com/p/closure-library/).
 * Use goog.require('goog.structs.PriorityQueue'); and new goog.structs.PriorityQueue()
 */
function PriorityQueue() {
    this._nodes = [];

    this.enqueue = function(priority, key) {
        this._nodes.push({
            key: key,
            priority: priority
        });
        this.sort();
    }
    ;
    this.dequeue = function() {
        return this._nodes.shift().key;
    }
    ;
    this.sort = function() {
        this._nodes.sort(function(a, b) {
            return a.priority - b.priority;
        });
    }
    ;
    this.isEmpty = function() {
        return !this._nodes.length;
    }
    ;
}

/**
 * Pathfinding starts here
 */
function Graph() {
    var INFINITY = 1 / 0;
    this.vertices = {};

    this.addVertex = function(name, edges) {
        this.vertices[name] = edges;
    }
    ;

    this.shortestPath = function(start, finish) {
        var nodes = new PriorityQueue(), distances = {}, previous = {}, path = [], smallest, vertex, neighbor, alt;

        for (vertex in this.vertices) {
            if (vertex === start) {
                distances[vertex] = 0;
                nodes.enqueue(0, vertex);
            } else {
                distances[vertex] = INFINITY;
                nodes.enqueue(INFINITY, vertex);
            }

            previous[vertex] = null;
        }

        while (!nodes.isEmpty()) {
            smallest = nodes.dequeue();

            if (smallest === finish) {
                path = [];

                while (previous[smallest]) {
                    path.push(smallest);
                    smallest = previous[smallest];
                }

                break;
            }

            if (!smallest || distances[smallest] === INFINITY) {
                continue;
            }

            for (neighbor in this.vertices[smallest]) {
                alt = distances[smallest] + this.vertices[smallest][neighbor];

                if (alt < distances[neighbor]) {
                    distances[neighbor] = alt;
                    previous[neighbor] = smallest;

                    nodes.enqueue(alt, neighbor);
                }
            }
        }

        return path;
    }
    ;
}

PipeBoardGenerator = function() {

    this.MAX_TRIES = 100;
    var types = {
        "32": 1,
        "23": 1,
        "03": 2,
        "30": 2,
        "01": 3,
        "10": 3,
        "12": 4,
        "21": 4,
        "13": 5,
        "31": 5,
        "02": 6,
        "20": 6
    };
    this.generate = function(width, height, length, fixed, holes) {
        var fixed = fixed || 0;
        var holes = holes || 0;
        var length = length || 6;
        var nodemap = null;

        for(var i = 0; i < this.MAX_TRIES; i++){
           nodemap = this._generate(width, height, length);
           if(nodemap != null){
               break;
           }
        }



         if(nodemap){

            
            var potentialHoles = {};
            for(var i = 0; i < width; i++){
                for(var j = 0; j < height; j++){
                    var key = i + "_" + j;
                    if(!nodemap[key] && nodemap[key] !== 0){
                        potentialHoles[key] = true;
                    }
                }
            }
            var holestr = "";
            for(var i = 0; i < holes; i ++){
                var nl = Object.keys(potentialHoles).length;
                if(nl > 0){
                    var prop = Object.keys(potentialHoles)[Math.floor(Math.random() * nl)];
                    holestr += prop[0];
                    holestr += prop[2];
                    delete potentialHoles[prop];                    
                }

            }

            var fixedstr = "";

            for(var i = 0; i < fixed; i ++){
                var nl = Object.keys(nodemap).length;
                var prop = Object.keys(nodemap)[Math.floor(Math.random() * nl)];
                fixedstr += prop[0];
                fixedstr += prop[2];
                fixedstr += nodemap[prop];
                delete nodemap[prop];
            }
            var str = "";
            var solutionStr = "";
            for(var prop in nodemap){
                str += nodemap[prop];
                solutionStr += prop[0];
                solutionStr += prop[2];
                solutionStr += nodemap[prop];
            }

            if(fixedstr){
                str += "_" + fixedstr;
            }
            if(holestr){
                str += "_" + holestr;
            }
            str += "|" + solutionStr;
            return str;
        }else {
            throw "max tries (" + this.MAX_TRIES + ") exceeded while creating grid " + width + "x" + height + ":" + length;
        }       
    };
    this._generate = function(width, height, length) {
        var g = new Graph();
        var nodemap = {};
        for (var i = 0; i < width; i++) {
            for (var j = 0; j < height; j++) {
                var key = i + "_" + j;
                //left
                var adjacent = {};
                if (i - 1 >= 0) {
                    adjacent[(i - 1) + "_" + j] = 1;
                }
                if (i + 1 < width) {
                    adjacent[(i + 1) + "_" + j] = 1;
                }
                if (j - 1 >= 0) {
                    adjacent[i + "_" + (j - 1)] = 1;
                }
                if (j + 1 < height) {
                    adjacent[i + "_" + (j + 1)] = 1;
                }
                g.addVertex(key, adjacent);
            }

        }
        var pluckVertices = function(node) {
            var type = nodemap[node];
            var tokens = node.split("_");
            var x = Number(tokens[0]);
            var y = Number(tokens[1]);

            delete g.vertices[node];
            var left = (x - 1) + "_" + y;
            var right = (x + 1) + "_" + y;
            var up = x + "_" + (y - 1);
            var down = x + "_" + (y + 1);
            if (g.vertices[left]) {
                delete g.vertices[left][node];
                // left to right cross on | pipe
                if (type == 6 && g.vertices[right]) {
                    g.vertices[left][right] = 2;
                }
            }
            ;if (g.vertices[right]) {
                delete g.vertices[right][node];
                // right to left cross on | pipe
                if (type == 6 && g.vertices[left]) {
                    g.vertices[right][left] = 2;
                }
            }
            ;if (g.vertices[up]) {
                delete g.vertices[up][node];
                // up to down cross on -- pipe
                if (type == 5 && g.vertices[down]) {
                    g.vertices[up][down] = 2;
                }
            }
            ;if (g.vertices[down]) {
                delete g.vertices[down][node];
                // down to up cross on -- pipe
                if (type == 5 && g.vertices[up]) {
                    g.vertices[down][up] = 2;
                }
            }
            ;

        }
        var rx = (Math.floor(Math.random() * (width - 2)) + 1);
        var ry = (Math.floor(Math.random() * (height - 2)) + 1);
        var root = rx + "_" + ry;
        var rt = Math.floor(Math.random() * 6) + 1;
        nodemap[root] = rt;
        pluckVertices(root);

        var sx = rx;
        var sy = ry;
        var dx = rx;
        var dy = ry;
        if (rt == 1) {
            sy += 1;
            dx -= 1;
        }
        if (rt == 2) {
            sy -= 1;
            dx -= 1;
        }
        if (rt == 3) {
            sy -= 1;
            dx += 1;
        }
        if (rt == 4) {
            sy += 1;
            dx += 1;
        }
        if (rt == 5) {
            sx -= 1;
            dx += 1;
        }
        if (rt == 6) {
            sy -= 1;
            dy += 1;
        }
        var temp = sx + '_' + sy;
        var dest = dx + "_" + dy;
        //console.log('root pipe: ' + root + ' begin at ' + temp + ' try to get to ' + dest);
        var trail = [];

        var setPipe = function(prev, current, next) {
            var adjacent = g.vertices[current];
            var tokens = current.split("_");
            var cx = Number(tokens[0]);
            var cy = Number(tokens[1]);
            tokens = next.split("_");
            var nx = Number(tokens[0]);
            var ny = Number(tokens[1]);
            //passing across a pipe
            if (adjacent[next] == 2) {
                nodemap[(cx + (nx - cx) / 2) + "_" + (cy + (ny - cy) / 2)] = 0;
            }

            var key = '';
            if (nx - cx < 0)
                key += '3';
            if (nx - cx > 0)
                key += '1';
            if (ny - cy < 0)
                key += '0';
            if (ny - cy > 0)
                key += '2';
            tokens = prev.split("_");
            var px = Number(tokens[0]);
            var py = Number(tokens[1]);
            if (px - cx < 0)
                key += '3';
            if (px - cx > 0)
                key += '1';
            if (py - cy < 0)
                key += '0';
            if (py - cy > 0)
                key += '2';
            nodemap[current] = types[key];
            pluckVertices(current);
        }

        var move = function(prev, current, index) {
            trail.push(current);
            var adjacent = g.vertices[current];
            var choices = [];
            for (var prop in adjacent) {
                var sp = g.shortestPath(prop, dest).length;
                if (sp > 0 && sp <= (index - adjacent[prop])) {
                    choices.push(prop);
                }
            }

            if (choices.length == 0) {
                if(index == 1 && adjacent[dest]){
                    setPipe(prev, current, dest);
                    setPipe(current, dest, root);
                    trail.push(dest);
                    trail.push(root);
                    //console.log("loop complete");
                    return true;
                }else {
                    //console.log("I fucked up... can't get to dest | pipes left:" + index);

                    return false;                    
                }

            } else {
                var next = choices[Math.floor(Math.random() * choices.length)];

                // found next choice, now see what kind of pipe is the current
                // depending on which is next and which is previous, pick from this.types
                setPipe(prev, current, next);
                return move(current, next, index - adjacent[next]);
            }

        }
        // Log test, with the addition of reversing the path and prepending the first node so it's more readable
        //console.log(g);

        if(move(root, temp, length)){
            return nodemap;         
        }else {
            return null;
        }

    }
}

Materialize.bonita = function(message, time) {
    Materialize.toast('<img style="max-height:40px; float:left;padding-right:5px;" src="images/bonita-87.png" alt="" class="circle">' + message, time);
}
;
MainView = Framework.TabView.extend({
    persistBy: 'mv',
    template: templatePath + 'templates/MainView.html',
    loadingTemplate: 'common/templates/Loading.html',
    events: function() {
        var parentEvents = Framework.TabView.prototype.events.call(this);
        return _.extend({}, parentEvents, {
            'click .wq-back-button': 'onBack',
            'click .wq-remove-ads': 'onRemoveAds',
            'click #onTutorial': 'onTutorial',
            'click .buy-tier': 'onBuyTier',
            'click #showHint': 'onShowHintHelp',
            'click #hintBomb': 'onHintBomb',
            'click #giveUp': 'onGiveUp',
            'click #reloadGameView': 'onReloadGameView',
            'click #reset' : 'onReset'
        });
    },
    onReset : function(){
      localStorage.reset = "true";
      this.setParameters({
          mv : 'levelsView'
      });
    },
    onReloadGameView: function() {
        this.trigger('reloadGameView');
        $('#reloadGameView').addClass('hide');
    },
    onGiveUp: function() {
        this.trigger('giveup');
        $('#giveUp').addClass('hide');
    },
    onHintBomb: function() {
        this.trigger('hintbomb');
    },
    onShowHintHelp: function() {
        Materialize.bonita('double tap on any tile to reveal a hint', 1000);
    },
    onBuyTier: function(e) {
        this.setParameters({
            mv: 'purchaseTierView'
        })
    },
    onTutorial: function() {
        this.setParameters({
            'mv': 'boardView',
            'bm': 'random',
            'd': 'tutorial'
        });
    },
    initialize: function(options) {
        //if someone came from non home url, correct history so 'back' actions work properly
        localStorage.hintbombs = localStorage.hintbombs || "0";
        localStorage.level = localStorage.level || "1";
        localStorage.scores = localStorage.scores || "[]";
        localStorage.tutorialComplete = localStorage.tutorialComplete || "false";
        localStorage.statisticsDisabled = localStorage.statisticsDisabled || "true";
        localStorage.hintHasBeenUsed = localStorage.hintHasBeenUsed || "false";
        Framework.TabView.prototype.initialize.call(this, options);
    },
    preloadDataAsync: function(callback) {
        var after = function() {
            callback();
        }
        .bind(this);
        ClientAccessBaseView.prototype.getClient(function(data) {
            after();
        }
        .bind(this), function(error) {
            delete localStorage.client;
            after();
        }
        .bind(this));

    },

    onRemoveAds: function() {
        this.setParameters({
            mv: 'removeAdsView'
        });
    },
    syncFromServer: true,
    render: function(callback) {
        Framework.TabView.prototype.render.call(this, callback);
        app.iw = window.innerWidth - 20;
        app.nh = (window.innerHeight - $('.navbar-fixed').height()) - 20;
        this.$('.wq-bonita-logo').sideNav({
            closeOnClick: true
        });
    },
    onBack: function() {
        history.back();
    },

});

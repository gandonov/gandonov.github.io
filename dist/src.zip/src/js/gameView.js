GameView = ScrabwordBoardView.extend({

    TOTAL_SPRITES: 12,
    FLOOR_TILE_SPRITE: 'sprite_0',
    HINT_SPRITE: 'sprite_11',
    AFFIXED_SPRITE: 'sprite_1',

    validate: function(lastTile) {

        if (lastTile) {
            var map = {};
            var place = function(map, node) {
                var type = "" + node.type;
                map[node.key] = node;
                switch (type) {
                case "0":
                case "2":
                case "3":
                case "6":
                    map[node.key + "_" + 0] = node;
                    break;
                }
                switch (type) {
                case "0":
                case "3":
                case "4":
                case "5":
                    map[node.key + "_" + 1] = node;
                    break;
                }
                switch (type) {
                case "0":
                case "1":
                case "4":
                case "6":
                    map[node.key + "_" + 2] = node;
                    break;
                }
                switch (type) {
                case "0":
                case "1":
                case "2":
                case "5":
                    map[node.key + "_" + 3] = node;
                    break;

                }
            }
            var maxLength = 0;
            for (var prop in this.hintMap) {

                maxLength += (this.hintMap[prop] === 0 ? 2 : 1);
                var node = {
                    unvisited: this.hintMap[prop] === 0 ? 2 : 1,
                    type: this.hintMap[prop],
                    key: prop
                };
                place(map, node);

            }
            for (var i = 0, l = this.letterTiles.length; i < l; i++) {

                var tile = this.letterTiles[i];
                var key = tile._boardX + "_" + tile._boardY;
                maxLength += (tile._letter === 0 ? 2 : 1);
                var node = {
                    type: tile._letter,
                    unvisited: tile._letter === 0 ? 2 : 1,
                    key: key
                };
                place(map, node);
            }
            var temp = map[lastTile._boardX + "_" + lastTile._boardY];
            var solution = lastTile._boardX + "" + lastTile._boardY;
            var initialNode = temp;
            var chainLength = 0;
            var prevy = null;
            var prevKey = null;
            var loop = false;
            while (temp) {
                solution += temp.type;
                chainLength++;
                temp.unvisited--;
                var key = temp.key;
                var tokens = key.split("_");
                var x = Number(tokens[0]);
                var y = Number(tokens[1]);
                var last = null;
                //console.log("type " + temp.type);
                var o1 = x + "_" + y;
                var o2 = x + "_" + y;
                switch (temp.type) {
                case 0:
                    if (!prevy || prevy != y) {
                        // act like case 6
                        o1 = x + "_" + (y - 1) + "_2";
                        o2 = x + "_" + (y + 1) + "_0";
                    } else {
                        //act like case 5
                        o1 = (x + 1) + "_" + y + "_3";
                        o2 = (x - 1) + "_" + y + "_1";
                    }
                    // can go anywhere depending on previous
                    break;
                case 1:
                    o1 = x + "_" + (y + 1) + "_0";
                    o2 = (x - 1) + "_" + y + "_1";
                    break;
                case 2:
                    o1 = x + "_" + (y - 1) + "_2";
                    o2 = (x - 1) + "_" + y + "_1";
                    break;
                case 3:
                    o1 = x + "_" + (y - 1) + "_2";
                    o2 = (x + 1) + "_" + y + "_3";
                    break;
                case 4:
                    o1 = x + "_" + (y + 1) + "_0";
                    o2 = (x + 1) + "_" + y + "_3";
                    break;
                case 5:
                    o1 = (x + 1) + "_" + y + "_3";
                    o2 = (x - 1) + "_" + y + "_1";
                    break;
                case 6:
                    o1 = x + "_" + (y - 1) + "_2";
                    o2 = x + "_" + (y + 1) + "_0";
                    break;
                }
                prevy = y;

                if (map[o1] && map[o1].key != prevKey && map[o1].unvisited > 0) {
                    temp = map[o1];
                } else if (map[o2] && map[o2].key != prevKey && map[o2].unvisited > 0) {
                    temp = map[o2];
                } else {
                    temp = null;
                }

                if (maxLength == chainLength && (map[o2] == initialNode || map[o1] == initialNode)) {
                    loop = true;
                }
                prevKey = key;

                //var type = temp.
            }

            //console.log(chainLength + " out of " + maxLength + " loop: " + loop);
            if (loop) {
                if (this.timerBar) {
                    this.stage.removeChild(this.timerBar);
                }
                this.endTime = Date.now() - this.startTime;
                this._endTimes.push(this.endTime);
                this._solution.push(solution);
                var text = this.messageOnComplete || 'complete';
                $('#giveUp').addClass('hide');
                this._handleValidSolutionAnimation(text, this.onDone.bind(this));
            }
        }

    },


    getCurrentSolution: function() {
        return [0];
    },

    _getTextedTile: function(letter, draggable, style) {

        var tile = draggable ? this.getDraggableTile('sprite_2') : this.getTile('sprite_1');
        //case "1": // 0,2
        var index = letter + 4;
        tile.addChild(this.getTile('sprite_' + index));
        tile._letter = letter;
        return tile;
    },

    onHashChange: function(map, diff) {
        map && map.mv == 'gameView' && this.renderView();
    },

    TUTORIAL_COMPLETE_MESSAGES: ["Drag & Drop Pieces To Form A Loop\nALL Pieces Must Be Used (Always)", "Double Tap Any Empty Tile\nTo Reveal a Hint.", "Click 'X' In the Top Right Corner\nTo Give Up And See Solution", ],

    generateLevel: function(level, perks) {
        perks = perks || []; 
        var perkmap = {};
        for(var i = 0, l = perks.length; i < l; i++){
            var p = perks[i];
            var tokens = p.split("/");
            var key = tokens[0];
            var value = tokens[1];
            if(key == "h"){
                perkmap[key] = perkmap[key] || 0;
                perkmap[key]+= Number(value);
            }else {
                perkmap[key] = value || true;
            }
        };

        var result = {};
        level.hints = level.hints || 0;
        result.hints = level.hints + (perkmap["h"] || 0);
        result.time = level.time;
        result.boards = [];
        result.options = [];
        var boards = level.boards;

        var b = new PipeBoardGenerator();
        for (var i = 0, l = boards.length; i < l; i++) {
            var board = boards[i];
            var options = {};
            if (board.dynamic) {
                var tokens = board.dynamic.split("|");
                var length = tokens[0] && Number(tokens[0]);
                var fixed = tokens[1] && Number(tokens[1]) || 0;
                var holes = tokens[2] && Number(tokens[2]) || 0;
                if(perkmap["lt"]){
                    holes *= 1.33;
                    if(holes < 8){
                        holes = 8;
                    }
                }
                var generated = b.generate(7, 7, length, fixed, holes);
                result.boards.push(generated);
            } else {

                result.boards.push(board.map);
            }
            options.unshuffled = true;
            options.message = board.message;
            options.messageOnComplete = board.messageOnComplete;
            options.nohints = board.nohints;
            options.time = board.time || 0;
            options.originalTime = options.time;
            if(options.time && perkmap["et"]){
                options.time = Math.floor(options.time * 1.25);
            }
            result.options.push(options);
        }
        return result;
    },

    bindSolutionToFloorTiles: function(solution) {
        if (solution instanceof Object) {
            solution = solution.solutions;
        }
        if (solution) {
            for (var i = 0, l = solution.length; i < l; i++) {
                var key = solution[i] + "_" + solution[++i];
                var type = Number(solution[++i]);
                for (var j = 0, l2 = this.letterTiles.length; j < l2; j++) {
                    var tile = this.letterTiles[j];
                    if (!tile._used && tile._letter === type) {
                        tile._used = true;
                        if (!this.floorTileMap[key]) {
                            console.log('something went wrong');
                        }
                        this.floorTileMap[key]._letterTile = tile;
                        break;
                    }
                }
            }
        }
    },

    loadBoard: function(board, options) {

        options = options || {};



        this.startTime = Date.now();
        this.stage.removeChildren();

        this.message = options.message;
        this.messageOnComplete = options.messageOnComplete;
        this.nohints = options.nohints;
        this.unshuffled = options.unshuffled;

        this.floorTiles = [];
        this.floorTileMap = {};
        this.letterTileMap = {};
        this.letterTiles = [];
        var lettersUsed = {};
        this.hintMap = {};
        this.hintTiles = [];
        var tokens = board.split('|');
        var solution = tokens[1];

        tokens = tokens[0].split("_");
        var fixed = tokens[1] || "";
        var letters = tokens[0];
        var holestr = tokens[2] || "";
        var holes = {};
        for (var i = 0, l = holestr.length; i < l; i++) {
            holes[holestr[i] + "_" + holestr[++i]] = true;
        }
        //var fixed = "";
        //var letters = [0, 1, 2, 3, 4, 5, 6];
        for (var i = 0, l = letters.length; i < l; i++) {
            var letterTile = this.getLetterTile(Number(letters[i]));
            this.letterTiles.push(letterTile);
            this.stage.addChild(letterTile);
        }

        for (var i = 0, l = fixed.length; i < l; i++) {
            var x = Number(fixed[i]);
            var y = Number(fixed[++i]);
            var type = Number(fixed[++i]);
            this.hintMap[x + "_" + y] = type;
            var tile = this.getHintTile(type);
            this.hintTiles.push(tile);
            this.stage.addChild(tile);
            this.putTile(tile, x, y);

        }

        for (var i = 0; i < 7; i++) {
            for (var j = 0; j < 7; j++) {
                var key = i + "_" + j;
                if (holes[key] || this.hintMap[key] || this.hintMap[key] === 0) {} else {
                    var tile = this.getFloorTile();
                    this.floorTiles.push(tile);
                    this.floorTileMap[key] = tile;
                    this.stage.addChild(tile);
                    this.putTile(tile, i, j);
                }

            }
        }

        /**
         * Randomize array element order in-place.
         * Using Durstenfeld shuffle algorithm.
         */
        for (var i = this.letterTiles.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));

            var temp = this.letterTiles[i];
            this.letterTiles[i] = this.letterTiles[j];
            this.letterTiles[j] = temp;
        }

        if (solution) {
            this.bindSolutionToFloorTiles(solution);
        }

        for (var i = 0, l = this.letterTiles.length; i < l; i++) {
            var tile = this.letterTiles[i];
            this.putBackInBank(tile, true);
        }
        this._setMessage();
        $('#giveUp').removeClass('hide');
        this.applyEffect('appear', this.stage, {
            duration: 500
        });
        if (options.time) {
            this.startTimer(1000 * options.time);
        }
        this.validate();
    },
});

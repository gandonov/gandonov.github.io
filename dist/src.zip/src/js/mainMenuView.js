MainMenuView = Framework.BaseView.extend({
    template: templatePath + 'templates/MainMenuView.html',
    snippets: {
        'statBox': 'common/templates/StatBoxSnippet.html'
    },
    events : {
        'click .btn-proxy' : "onProxy"
    },

    onProxy : function(e){
        $('#' + $(e.currentTarget).data('proxy')).click();
    },

    // TODO -- move this lock to framework?
    render: function(){
      Framework.BaseView.prototype.render.call(this);
      delete this.__rendering;  
    },

    renderView : function(callback){
        if(this.__rendering){
            // do nothing, already rendering
        }else {
            this.__rendering = true;
            Framework.BaseView.prototype.renderView.call(this, callback);
        }
    },
    onHashChange : function(map){
        (this.getParameter('mv') == 'newGameView' || this.getParameter('mv') == null) && this.renderView();
    }
});

(function(exports) {
    exports.WQConfig = {
        product: 'loopypipes',
        admob: {
            android: 'ca-app-pub-4612592091560420/9499820397',
            ios: 'ca-app-pub-4612592091560420/4317584398'
        },
        defaultVolume: 1.0,
        gameTitle: "Loopy Pipes",
        testAds: false,
        MENU_VIBRATION: 20,
        MAX_NAME_LENGTH: 15,
        MAX_SCORES_IN_TOP_LIST: 50,
        renderer: {
            DONE_VIBRATION_DURATION: 50,
            DONE_VIBRATION_DURATION_SHORT: 10,
        },
        
        tutorial: {
            "hints": 15,
            "boards": [{
                // [pipeTypes(1char)] || _ (separator) || [fixed x, fixed y]  
                "map": "1345351_120332|111014023225321235133",
                "messageOnComplete": "Great!",
                "message": "Drag & Drop Wooden Pieces\nTo Form A Loop",
                "time": 0
            }]
        },

        urls: {
            facebookshare: "http://www.facebook.com/sharer/sharer.php?u=www.scrabword.com",
            playstore: "https://play.google.com/store/apps/details?id=com.bonitabytes.scrabword",
            appstore: "https://itunes.apple.com/us/app/scrabword-word-puzzle-challenge/id1127637656?ls=1&mt=8",
            audio: {
                'placetile': 'common/resources/sounds/placetile.m4a',
                'complete': 'common/resources/sounds/complete.m4a',
                'incomplete': 'common/resources/sounds/incomplete.m4a',
                'hovertile': 'common/resources/sounds/hovertile.m4a',
                'wood': 'common/resources/sounds/wood.m4a',
                'hintBomb': 'common/resources/sounds/d.mp3'
            },
            website: 'http://scrabword.com',
            medalLinks: ["common/resources/images/ranked/medal1.png", "common/resources/images/ranked/medal2.png", "common/resources/images/ranked/medal3.png"],
            share: "https://yyqdb8lpbe.execute-api.us-east-1.amazonaws.com/dev/share",
            api: "https://yyqdb8lpbe.execute-api.us-east-1.amazonaws.com/prod/api",
            products: "https://usecy6s9nd.execute-api.us-east-1.amazonaws.com/prod/products"
        }
    };

})(typeof exports === 'undefined' ? this['WQConfig'] = {} : exports);
if (typeof exports === 'undefined') {
    window.WQConfig = WQConfig.WQConfig;
}

ProductsView = Framework.BaseView.extend({
    
    template: templatePath + 'templates/tabs/ProductsView.html',
    loadingTemplate: templatePath + 'templates/Loading.html',
    errorTemplate: templatePath + 'templates/tabs/ProductsViewError.html',

    events : {
       'click .wq-store-link' : 'onStoreLink'
    },

    onStoreLink : function(e){
        e.preventDefault();
        e.stopPropagation();
        var $el = $(e.currentTarget);
        var href = $el.attr('href');
        window.open(href, '_system');  
    },

    preloadDataAsync : function(callback, error){
        var cb = function(data){
            localStorage.productCount = data.Count;
            $('.wq-new,.wq-new-menu').remove();
            var parent = this.getParent();
            parent.showAnotherGameButton = false;
            callback(data);
        }.bind(this);
        this.getJSON(WQConfig.urls.products + '?product=' + WQConfig.product, cb, error);
    }
});
ScoreListView = Framework.BaseView.extend({
    
    template: templatePath + 'common/templates/ScoreListView.html',
    loadingTemplate: templatePath + 'common/templates/Loading.html',
    errorTemplate: templatePath + 'common/templates/ScoreListViewError.html',
    snippets: {
        'top50list': templatePath + 'common/templates/top50listSnippet.html'
    },
    events: {
        'click #changeName': 'onChangeName'
    },
    onChangeName: function() {
        this.setParameters({
            bm: null,
            bid: null,
            mv: 'changeNameView'
        });
    },
    // TODO -- move this lock to framework?
    render: function(){
      Framework.BaseView.prototype.render.call(this);
      delete this.__rendering;  
    },

    renderView : function(callback){
        if(this.__rendering){
            // do nothing, already rendering
        }else {
            this.__rendering = true;
            Framework.BaseView.prototype.renderView.call(this, callback);
        }
    },
    onHashChange : function(map){
        this.getParameter('mv') == 'scoreListView' && this.renderView();
    },
    preloadDataAsync: function(callback, error) {
        var client = localStorage.client;
        client = client && JSON.parse(client);
        if (!client) {
            error("no local client copy");
            return;
        }
        this.postJSON(WQConfig.urls.api, function(data) {
            //var scores = _.sortBy(data.unsortedScoreArray, 'score').reverse();
            // there might be some left overs from asynchronous delete errors, don't show extra.
            //scores = scores.slice(0, WQConfig.MAX_SCORES_IN_TOP_LIST);
            var result = {
                stats: data.stats,
                scores: data.scores,
                myscore: data.client.score,
                cname: data.client.cname
            }
            callback(result);
            this.trigger('success');
        }
        .bind(this), error, {
            clientid: client.clientid,
            product: WQConfig.product,
            operation: "scores"
        });
    }
});

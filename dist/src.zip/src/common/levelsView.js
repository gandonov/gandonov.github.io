LevelsView = Framework.BaseView.extend({
    template: 'common/templates/LevelsView.html',

    events: {
        'click .wq-play-level': 'onPlayLevel'
    },

    loadingTemplate: 'common/templates/Loading.html',

    snippets: {
        'transitionInfoBox': 'common/templates/TransitionInfoBoxSnippet.html'
    },

    onHashChange: function() {
        if (this.getParameter('mv') == 'levelsView') {
            this.renderView();
        }
    },

    romanize: function(num) {
        if (!+num)
            return false;
        var digits = String(+num).split("")
          , key = ["", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM", "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC", "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"]
          , roman = ""
          , i = 3;
        while (i--)
            roman = (key[+digits.pop() + (i * 10)] || "") + roman;
        return Array(+digits.join("") + 1).join("M") + roman;
    },

    onPlayLevel: function(e) {
        var $el = $(e.currentTarget);
        var id = $el.data('id');
        localStorage.targetLevel = id;
        this.setParameters({
            mv: 'gameView',
            bm: 'level',
            l: id + 1,
        })
    },
    _computeStars: function() {
        var scores = JSON.parse(localStorage.scores);
        var totalStars = 0;
        for (var i = 0, l = scores.length; i < l; i++) {
            var score = scores[i];
            totalStars += score;
        }
        return totalStars;
    },
    render: function() {
        
        var targetLevel = localStorage.targetLevel ? localStorage.targetLevel : 0;
        var stars = this._computeStars();
        $('#totalLevelStars').html(stars);
        var $transitionInfoBox = this.$('.level-status[data-position="' + (Number(targetLevel) - 1) + '"]');
        if ($transitionInfoBox.length > 0) {
            $('html, body').animate({
                scrollTop: $transitionInfoBox.offset().top - 60
            }, 400);
        }
    }
});

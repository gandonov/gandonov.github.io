SettingsView = Framework.BaseView.extend({
    template: 'common/templates/SettingsView.html',
    localStorageFlags: {
        'general': {},
        'validation': {
            'validationCheckMarks': 'checkmarks',
            'validationCheckMarks': 'letter highlight'
        }
    },
    preloadDataAsync: function(callback) {
        var data = {
            preferredId: ClientAccessBaseView.prototype._preferredId()
        };
        callback(data);
    },
    events: {
        'change input': 'onInputChange',
        'click #clearCache': 'onClearCache'
    },
    onClearCache: function() {
        localStorage.clear();
        Materialize.bonita('cache cleared.', 300);
        location.reload();
    },
    onInputChange: function() {
        var vibrationsDisabled = !this.$('#vibrations').prop('checked');
        var statisticsDisabled = !this.$('#statistics').prop('checked');
        var soundDisabled = !this.$('#sounds').prop('checked');
        localStorage.vibrationsDisabled = vibrationsDisabled;
        localStorage.soundDisabled = soundDisabled;
        localStorage.statisticsDisabled = statisticsDisabled;
        Materialize.bonita('settings updated', 250);
    }
});

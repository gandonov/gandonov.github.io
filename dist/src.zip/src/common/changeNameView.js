ChangeNameView = Framework.BaseView.extend({
    template: templatePath + 'common/templates/ChangeNameView.html',
    loadingTemplate: templatePath + 'common/templates/Loading.html',

    events: {
        'click #changeName': 'onChangeName'
    },
    preloadDataAsync: function(callback, error) {
        var client = localStorage.client && JSON.parse(localStorage.client);
        if (client) {
            callback(client.cname);
        } else {
            error("client is not in localStorage.");
        }
    },
    onHashChange: function() {
        var mv = this.getParameter('mv');
        if (mv == null || mv == 'changeNameView') {
            this.renderView();
        }
    },

    onChangeName: function() {
        var val = this.$('#name').val();
        var complete = function() {
            history.back();
        }
        .bind(this);

        if (!val || val == "") {
            complete();
        } else {
            this.setOverlay();
            var error = function(msg){
                Materialize.bonita(msg);
                complete();
            }
            var success = function(data) {
                if (data.errorMessage) {
                    Materialize.bonita(data.errorMessage);
                }
                complete();
                //this.removeOverlay();
            }
            .bind(this);
            ClientAccessBaseView.prototype.updateName.call(this,val,success,error);
        }
    },

    render: function() {
        this.$('input').characterCounter();
        this.$('#name').focus();
        this.$('#name').select();

        this.$('form').on('keyup', function(e) {
            if (e.keyCode == 13) {
                this.onChangeName();
            }
        }
        .bind(this));
    }
});

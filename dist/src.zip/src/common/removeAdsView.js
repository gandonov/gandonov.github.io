StoreAccessView = Framework.BaseView.extend({
    _onProductLoaded: function(product) {

    },
    products: [{
        id: 'hintbomb_0',
        type: 'non consumable'
    },
    {
        id: 'hintbomb_1',
        type: 'non consumable'
    },
    {
        id: 'hintbomb_2',
        type: 'non consumable'
    },
    {
        id: 'noads',
        type: 'non consumable'
    }],
    initialize: function(options) {
        if (!app.isBrowser && /(android)/i.test(navigator.userAgent) && !this.registered) {
            var counter = 0;
            for(var i = 0 , l = this.products.length; i < l;i++){
                var p = this.products[i];
                window.store.register(p);
                store.when(p.id, "loaded", function(){
                   
                   this._onProductLoaded(store.get(p.id)); 
                    counter++;
                    if(counter == this.products.length){
                        this._onAllProductsLoaded();
                    }
                }.bind(this));
            };
            
            this.registered = true;
        } else {
            this.template = templatePath + 'templates/DeviceNotSupported.html'
        }
        Framework.BaseView.prototype.initialize.call(this, options);
    },
});
StoreView = StoreAccessView.extend({
    template: templatePath + 'templates/tabs/StoreStatsView.html',

    initialize : function(options){
        StoreAccessView.prototype.initialize.call(this, options);
        if(!this.bindRemoveAdsViewListenerFunctions){
            store.when("noads").updated(function(){
                this._onRemoveAdsUpdated("noads");
            }.bind(this));
             store.when("hintbomb_0").updated(function(){
                this._onRemoveAdsUpdated("hintbomb_0");
            }.bind(this));
            this.bindRemoveAdsViewListenerFunctions = true;
        }
    },


    render : function(){
      store.refresh();  
    },

    _onAllProductsLoaded: function(){
        for(var i = 0, l = this.products.length; i < l;i++){
            var p = store.get(this.products[i].id);
            this.addProductInfo(p);
        }
    },

    addProductInfo: function(product) {
        if(product){
            var str = JSON.stringify(product);
            var html = "<div class='row wq-store-product'><div class='col s12'>" + product.id;
            html += "</div><div class='col s12'>" + str + '</div></div>';
             
            this.$('#products').append(html);
        }else {
            Materialize.bonita("Something went horribly wrong...");
        }
    },

    _onRemoveAdsFinished : function(){
        Materialize.bonita("finished trigerred");

    },

    _onRemoveAdsUpdated : function(name){
        var p = store.get(name);
        app.log('onupdate[' + name + ']  = ' + JSON.stringify(p));
    },

    _onRemoveAdsApproved : function(){
        Materialize.bonita("approved Approved.");
    },

});
RemoveAdsView = StoreAccessView.extend({
    
    events: {
        'click #buy': 'onBuy'
    },
    _onRemoveAdsFinished : function(){
        Materialize.bonita("transaction Finished.");
        localStorage.noads = "true";
        window.location.reload();
    },
    _onRemoveAdsApproved : function(){
        Materialize.bonita("transaction Approved.");
        var p = store.get('noads');
        localStorage.noads = "true";
        p.finish();
    },

    onBuy : function(){
        store.order("noads");
    },

    initialize : function(options){
        StoreAccessView.prototype.initialize.call(this, options);
        if(!this.bindRemoveAdsViewListenerFunctions){
            store.when("noads").approved(this._onRemoveAdsApproved.bind(this));
            store.when("noads").finished(this._onRemoveAdsFinished.bind(this));
            this.bindRemoveAdsViewListenerFunctions = true;
        }
    },

    template: templatePath + 'templates/tabs/RemoveAdsView.html',
        render : function(){
      store.refresh();  
    },

    _onAllProductsLoaded: function(){

        var p = store.get("noads");
        this.$('#buy').html(p.price);
        this.$('#buy').removeClass('hide');
    },

});
PurchaseTierView = StoreAccessView.extend({
    template: templatePath + 'templates/tabs/PurchaseTierView.html',
    events: {
        'click #buy': 'onBuy'
    },
    _buy: function() {
        if (!window.store) {
            throw "window.store not defined for some reason.";
        }
        window.store.register({
            id: 'hintbomb',
            type: window.store.NON_CONSUMABLE
        });
        store.when("hintbomb").owned(function(s) {
            Materialize.bonita("Owned!!!");
        });
        store.ready(function(s) {
            Materialize.bonita("Success on ready! Ordering the bomb", 3000);
            store.order("hintbomb");
        });
        store.error(function(s) {
            Materialize.bonita("Error in store has occurred :-(", 3000);
            if (s) {
                Materialize.bonita(JSON.stringify(s));
            }
        });
        Materialize.bonita("refreshing...", 3000);
        store.refresh();
    },
    onBuy: function() {
        if (!app.isBrowser && /(android)/i.test(navigator.userAgent)) {
            Materialize.bonita("Initiating...", 2000);
            try {
                this._buy();
            } catch (e) {
                Materialize.bonita(e);
            }
        } else {
            Materialize.bonita('Not available on this platform. Sorry', 3000);
        }
    },
    render: function() {}
});

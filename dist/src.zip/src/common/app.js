var orgConsoleLog = console.log;
var orgTime = Date.now();
function getWebPath() {
    "use strict";
    var path = window.location.pathname;
    path = path.substring(0, path.lastIndexOf('/'));
    return 'file://' + path;
}
function getWebRoot() {
    "use strict";
    var path = window.location.href;
    path = path.substring(0, path.lastIndexOf('/'));
    return path;
}
/*
 * Please see the included README.md file for license terms and conditions.
 */
/*jslint browser:true, devel:true, white:true, vars:true */
/*global $:false, intel:false app:false, dev:false, cordova:false, Media:false */
// This file contains your event handlers, the center of your application.
// NOTE: see app.initEvents() in init-app.js for event handler initialization code.
function myEventHandler() {
    "use strict";
    var isBrowser = false;
    var ua = navigator.userAgent;
    var str;
    if (window.Cordova && dev.isDeviceReady.c_cordova_ready__) {
        str = "It worked! Cordova device ready detected at " + dev.isDeviceReady.c_cordova_ready__ + " milliseconds!";
    } else if (window.intel && intel.xdk && dev.isDeviceReady.d_xdk_ready______) {
        str = "It worked! Intel XDK device ready detected at " + dev.isDeviceReady.d_xdk_ready______ + " milliseconds!";
    } else {
        isBrowser = true;
        str = "Bad device ready, or none available because we're running in a browser.";
    }
    console.log(str);
    return isBrowser;
}
function emulator() {
    console.log('This app uses a third party Admob plugin. Please build app to test.');
}
// ...additional event handlers here...
function initAdMob() {}
function createInterstitial() {
    "use strict";
    var fName = "createInterstitial():";
    console.log(fName, "entry");
    if (window.tinyHippos) {
        emulator();
        console.log(fName, "emulator alert");
    } else {
        window.plugins.AdMob.createInterstitialView();
    }
    console.log(fName, "exit");
}
function showInterstitial() {
    "use strict";
    var fName = "showInterstitial():";
    console.log(fName, "entry");
    try {
        if (window.tinyHippos) {
            emulator();
            console.log(fName, "emulator alert");
        } else {
            window.plugins.AdMob.showInterstitialAd(true, function() {}, function(e) {
                alert(JSON.stringify(e));
            });
        }
    } catch (e) {
        console.log(fName, "catch, failure");
    }
    console.log(fName, "exit");
}
/*
 * Please see the included README.md file for license terms and conditions.
 */
// This file is a suggested initialization place for your code.
// It is completely optional and not required.
// It implements a Cordova "hide splashscreen" function, that may be useful.
// Note the reference that includes it in the index.html file.
/*jslint browser:true, devel:true, white:true, vars:true */
/*global $:false, intel:false, app:false, dev:false */
/*global myEventHandler:false, cordova:false, device:false */
window.app = window.app || {};
app.HTML5Sound = function(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function() {
        this.sound.play();
    }
    this.stop = function() {
        this.sound.pause();
    }
}
app.audioLoadSuccess = function(msg) {
    app.debug("audio loaded successfully - " + msg);
}
app.audioLoadError = function(msg) {
    app.debug("audio failed to load - " + msg);
}
app.loadMedia = function() {
    if (Media) {
        var resources = WQConfig.urls.audio;
        this.MediaSounds = {};
        for (var prop in resources) {
            try {
                var w = window.device && window.device.platform;
                var x = navigator.userAgent;
                var y = getWebPath();
                var z = getWebRoot();
                this.consoleLog(fName, "platform = ", w);
                this.consoleLog(fName, "userAgent = ", x);
                this.consoleLog(fName, "getWebPath() => ", y);
                this.consoleLog(fName, "getWebRoot() => ", z);
                var media = resources[prop];
                //        if( z.match(/\/emulator.*\/ripple\/userapp/i) ) {           // if in the Emulate tab
                if (window.tinyHippos) {
                    // if in the Emulate tab
                    media = z + "/" + media;
                } else if (x.match(/(ios)|(iphone)|(ipod)|(ipad)/ig)) {
                    // if on a real iOS device
                    media = "/" + media;
                } else {
                    // everything else...
                    media = z + "/" + media;
                }
                this.MediaSounds[prop] = new Media(media,function() {//Materialize.bonita('success', 2000)
                }
                ,function(err) {//Materialize.bonita('error : ' + JSON.stringify(err), 2000)
                }
                );
            } catch (e) {
                this.consoleLog(fName, "try failed:", e);
            }
        }
    } else {
        Materialize.bonita("something went wrong -- no Media plug in", 3000);
    }
}
app.loadNativeAudio = function() {
    if (window.plugins && window.plugins.NativeAudio) {
        var resources = WQConfig.urls.audio;
        for (var prop in resources) {
            window.plugins.NativeAudio.preloadComplex(prop, resources[prop], WQConfig.defaultVolume, 1, 0, this.audioLoadSuccess, this.audioLoadError);
        }
    } else {
        app.debug("something went wrong -- no NativeAudio plug in", 1000);
        //Materialize.bonita("something went wrong -- no NativeAudio plug in", 1000);
    }
}
app.loadHTML5Audio = function() {
    var resources = WQConfig.urls.audio;
    this.HTML5Sounds = {};
    for (var prop in resources) {
        this.HTML5Sounds[prop] = new this.HTML5Sound(resources[prop]);
    }
    app.debug("loaded audios no problem.", 1000);
}
app.playNativeAudio = function(id) {
    if (window.plugins && window.plugins.NativeAudio) {
        window.plugins.NativeAudio.play(id);
    } else {
        app.debug("something went wrong -- no NativeAudio plug in", 1000);
        //Materialize.bonita("something went wrong -- no NativeAudio plug in", 1000);
    }
}
app.playSound = function(resource) {
    if (!localStorage.soundDisabled || localStorage.soundDisabled == "false") {
        // to play html5 if ios or browser. || /(ipod|iphone|ipad|ios)/i.test(navigator.userAgent)
        try {
            app.isBrowser ? app.HTML5Sounds[resource].play() : this.playNativeAudio(resource);
        } catch (e) {
            this.debug(JSON.stringify(e));
        }
    }
}
app.debug = function(message, milliseconds) {
    if (WQConfig.debug) {
        Materialize.bonita("DEBUG:" + message, milliseconds);
    }
}
// Set to "true" if you want the console.log messages to appear.
app.LOG = app.LOG || true;
app.consoleLog = function() {
    // only emits console.log messages if app.LOG != false
    if (app.LOG) {
        var args = Array.prototype.slice.call(arguments, 0);
        console.log.apply(console, args);
    }
}
;
// App init point (runs on custom app.Ready event from init-dev.js).
// Runs after underlying device native code and webview/browser is ready.
// Where you should "kick off" your application by initializing app events, etc.
// NOTE: Customize this function to initialize your application, as needed.
app.remoteUrl = 'http://default-environment-vt6hppgp7u.elasticbeanstalk.com';
app.initEvents = function() {
    "use strict";
    console.log('init events called');
    var fName = "app.initEvents():";
    app.consoleLog(fName, "entry");
    // NOTE: initialize your third-party libraries and event handlers
    // initThirdPartyLibraryNumberOne() ;
    // initThirdPartyLibraryNumberTwo() ;
    // initThirdPartyLibraryNumberEtc() ;
    // NOTE: initialize your application code
    var isBrowser = myEventHandler();
    app.isBrowser = isBrowser;
    app.serverUrl = isBrowser ? '' : app.remoteUrl;
    // NOTE: initialize your app event handlers, see app.js for a simple event handler example
    // TODO: configure following to work with both touch and click events (mouse + touch)
    // see http://msopentech.com/blog/2013/09/16/add-pinch-pointer-events-apache-cordova-phonegap-app/
    var el, evt;
    if (navigator.msPointerEnabled || !('ontouchend'in window))
        // if on Win 8 machine or no touch
        evt = "click";
        // let touch become a click event
    else
        // else, assume touch events available
        evt = "touchend";
    if (!app.isBrowser) {
        //Materialize.toast('initializing AdMob...');
        this.admobid = {};
        if (/(android)/i.test(navigator.userAgent)) {
            this.admobid = {
                // for Android
                banner: 'ca-app-pub-6869992474017983/9375997553',
                interstitial: WQConfig.admob.android
            };
        } else if (/(ipod|iphone|ipad)/i.test(navigator.userAgent)) {
            this.admobid = {
                // for iOS
                banner: 'ca-app-pub-6869992474017983/4806197152',
                interstitial: WQConfig.admob.ios
            };
        } else {
            this.admobid = {
                // for Windows Phone
                banner: 'ca-app-pub-6869992474017983/8878394753',
                interstitial: WQConfig.admob.android
            };
        }
        try {
            if (!AdMob) {
                app.debug('admob plugin not ready');
                return;
            } else {
                // Materialize.toast('admob plugin initialized successfully.');
                AdMob.setOptions({
                    // adSize: 'SMART_BANNER',
                    // width: integer, // valid when set adSize 'CUSTOM'
                    // height: integer, // valid when set adSize 'CUSTOM'
                    position: AdMob.AD_POSITION.BOTTOM_CENTER,
                    // offsetTopBar: false, // avoid overlapped by status bar, for iOS7+
                    bgColor: 'black',
                    // color name, or '#RRGGBB'
                    // x: integer,    // valid when set position to 0 / POS_XY
                    // y: integer,    // valid when set position to 0 / POS_XY
                    isTesting: WQConfig.testAds,
                    // set to true, to receiving test ad for testing purpose
                    // autoShow: true // auto show interstitial ad when loaded, set to false if prepare/show
                });
            }
        } catch (e) {
            app.debug(e);
        }
        // Materialize.toast('preparing interstitial with id ' + this.admobid.interstitial);
    }
    // to play html5 if ios or browser. || /(ipod|iphone|ipad|ios)/i.test(navigator.userAgent)
    if (app.isBrowser) {
        app.loadHTML5Audio();
    } else {
        app.loadNativeAudio();
    }
    var onLoad = function() {
        var done = function() {
            app.mainView = new MainView();
            app.mainView.setElement($('#mainView')).renderView();
            app.hideSplashScreen();
        }
        .bind(this);
        if (window.FW_USE_PACKED) {
            $.ajax({
                url: 'templates.html',
                method: 'GET',
                success: function(response) {
                    Framework.loadCompressed(response);
                    done();
                }
                .bind(this),
                error: function(response) {
                    console.log('error');
                }
            })
        } else {
            done();
        }
    }
    var language = localStorage.language;
    if (!language) {
        language = 'en';
        localStorage.setItem('language', language);
    }
    // types: debug, error, info, stats
    app.log = function(message, type, callback, error) {
        var callback = callback || function(){};
        var error = error || function(){};
        var client = JSON.parse(localStorage.client);
        var payload = {
            operation: "log",
            product: WQConfig.product,
            clientid: client.clientid,
            data : message
        };
        if(type){
            payload["type"] = type;
        }
        Framework.BaseView.prototype.postJSON(WQConfig.urls.api, function(response) {
            callback(response);
        }, error, payload , null,{ timeout : 8000});
    }
    onLoad();
    document.body.onmousedown = function() {
        if (app.isMouseDown === undefined) {
            app.isMouseDown = 0;
        }
        app.isMouseDown++;
    }
    document.body.onmouseup = function() {
        if (app.isMouseDown === undefined) {
            app.isMouseDown = 0;
        }
        app.isMouseDown--;
    }
}
;
document.addEventListener("app.Ready", app.initEvents, false);
document.addEventListener('onAdLoaded', function(data) {
    if (data.adType == 'banner')
        AdMob.showBanner();
    else if (data.adType == 'interstitial') {
        app.adLoaded = true;
    }
});
document.addEventListener('onAdFailLoad', function(data) {
    console.log(data.error + ',' + data.reason);
    if (data.adType == 'banner')
        AdMob.hideBanner();
    else if (data.adType == 'interstitial') {
        app.adLoaded = false;
    }
});
app.vibrate = function(long, custom) {
    if (!localStorage.vibrationsDisabled || localStorage.vibrationsDisabled == "false") {
        if (navigator && navigator.vibrate) {
            var l = long ? WQConfig.renderer.DONE_VIBRATION_DURATION : WQConfig.renderer.DONE_VIBRATION_DURATION_SHORT;
            if (custom) {
                l = custom;
            }
            navigator.vibrate(l);
        }
    }
}
app.prepareInterstitial = function() {
    var id = WQConfig.admob.android;
    if (/(android)/i.test(navigator.userAgent)) {
        id = WQConfig.admob.android;
    } else if (/(ipod|iphone|ipad)/i.test(navigator.userAgent)) {
        id = WQConfig.admob.ios;
    } else {
        id = WQConfig.admob.android;
    }
    if (!app.isBrowser && !WQConfig.purchased) {
        if (AdMob) {
            AdMob.prepareInterstitial({
                adId: id,
                autoShow: false,
            });
        }
    }
}
app.initDebug = function() {}
;
// Using a splash screen is optional. This function will not fail if none is present.
// This is also a simple study in the art of multi-platform device API detection.
app.hideSplashScreen = function() {
    "use strict";
    var fName = "app.hideSplashScreen():";
    //app.consoleLog(fName, "entry");
    // see https://github.com/01org/appframework/blob/master/documentation/detail/%24.ui.launch.md
    // Do the following if you disabled App Framework autolaunch (in index.html, for example)
    // $.ui.launch() ;
    if (navigator.splashscreen && navigator.splashscreen.hide) {
        // Cordova API detected
        navigator.splashscreen.hide();
    }
    if (window.intel && intel.xdk && intel.xdk.device) {
        // Intel XDK device API detected, but...
        if (intel.xdk.device.hideSplashScreen)
            // ...hideSplashScreen() is inside the base plugin
            intel.xdk.device.hideSplashScreen();
    }
    // app.consoleLog(fName, "exit");
}

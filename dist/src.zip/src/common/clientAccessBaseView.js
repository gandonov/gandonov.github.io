ClientAccessBaseView = Framework.BaseView.extend({
    MAX_CLIENT_CACHE: 86400000,
//     preloadDataAsync: function(callback, error) {
//         this.getClient(callback, error);
//     },
    _preferredId: function() {
        var client = localStorage.client;
        client = client && JSON.parse(client);
        if (client) {
            return client.clientid;
        }
        if (app.isBrowser) {
            return "browser-" + Date.now();
        } else {
            if (window.device && window.device.uuid) {
                return window.device.uuid;
            } else {
                return "cordova-" + Date.now();
            }
        }
    },

    updateName : function(name, callback, error){

        var client = localStorage.client && JSON.parse(localStorage.client);
        if (client) {
            var success = function(data){
                if(data.errorMessage){
                    error(data.errorMessage);
                }else {
                    client.cname = name;
                    localStorage.client = JSON.stringify(client);
                    callback(name);                    
                }

            }.bind(this);
            this.postJSON(WQConfig.urls.api, success, error, {
                clientid: client.clientid,
                product: WQConfig.product,
                operation: "updateName",
                cname: name
            });
        }else {
            error("client is not in localStorage");
        }
    },
    getClient: function(callback, error) {
        
        var client = localStorage.client;
        try{
            client = client && JSON.parse(client);
        } catch(e){
            app.log('user was unable to access local client due to JSON.parse error.');
        }
        if (client && client.cacheDate + this.MAX_CLIENT_CACHE > Date.now()) {
            callback(client);
            return;
        }
        this.postJSON(WQConfig.urls.api, function(client) {
            client.cacheDate = Date.now();
            localStorage.client = JSON.stringify(client);
            callback(client);
        }, function(err){
            delete localStorage.client;
            error(err); 
        }.bind(this), {
            operation: "get",
            product: WQConfig.product,
            clientid: this._preferredId()
        }, null, {
            timeout: 8000
        });
    }
});

// for this implementation provide dom <img> element with src poiting to your spritesheet
SpriteBoardView = AbstractBoardView.extend({

    SPRITE_SHEET_IMG: '#spriteSheet',
    SPRITE_WIDTH: 50,
    SPRITE_HEIGHT: 50,
    TOTAL_SPRITES: 6,

    initialize: function(options) {
        AbstractBoardView.prototype.initialize.call(this, options);
    },
    _spriteInit: function(callback, error) {
        if (this._spriteInitDone) {
            callback && callback();
            return;
        }
        var spriteSheet = $(this.SPRITE_SHEET_IMG)[0];
        var afterLoad = function() {
            var baseTexture = new PIXI.BaseTexture(spriteSheet);
            for (var i = 0; i < this.TOTAL_SPRITES; i++) {
                PIXI.utils.TextureCache['sprite_' + i] = new PIXI.Texture(baseTexture);
                PIXI.utils.TextureCache['sprite_' + i].frame = new PIXI.Rectangle(i * this.SPRITE_WIDTH,0,this.SPRITE_WIDTH,this.SPRITE_HEIGHT);
            }
            this._spriteInitDone = true;
            callback && callback();
        }
        .bind(this);
        if (spriteSheet.complete) {
            afterLoad();
        } else {
            spriteSheet.onload = afterLoad;
        }
    },
    preloadDataAsync: function(callback, error) {
        if (!this.SPRITE_SHEET_IMG || !this.SPRITE_HEIGHT || !this.SPRITE_WIDTH || !this.TOTAL_SPRITES) {
            throw "this AbstractBoardView implementation requires SPRITE_SHEET_IMG, SPRITE_HEIGHT, SPRITE_WIDTH, TOTAL_SPRITES fields to be specified.";
        }
        this._spriteInit(function() {
            this.setup();
            callback();
        }
        .bind(this), error);
    }
});

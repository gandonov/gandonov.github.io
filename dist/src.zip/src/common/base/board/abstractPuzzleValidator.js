AbstractPuzzleValidator = Framework.BaseView.extend({
    // 0 -- n/a
    // 1 -- correct
    // -1 -- incorrect;
    validate : function(solution){
        var result = [];
        for(var i = 0, l = solution.length; i < l;i++){
            result.push(0);
        }
    } 
});
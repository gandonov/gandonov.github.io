AbstractBoardView = Framework.BaseView.extend({
    effects: {},
    loadingTemplate: 'common/templates/Loading.html',
    initialize: function(options) {
        Framework.BaseView.prototype.initialize.call(this, options);
        this.MAGINIFICATION_FACTOR = 1.13;
        this.LETTER_WIDTH = 50;
        this.LETTER_HEIGHT = 50;
        this.LETTER_SCALED_WIDTH = this.LETTER_WIDTH;
        this.LETTER_SCALED_HEIGHT = this.LETTER_HEIGHT;
        this.TEXTURE_LETTERS_PER_ROW = 10;
        this.LETTERS_PER_BANK_ROW = 7;
        this.LETTERS_PER_ROW = 7;
        this.BANK_X_START = 0;
        this.BANK_Y_START = 8;
        this.RENDERER_WIDTH = (this.LETTERS_PER_BANK_ROW) * this.LETTER_WIDTH;
        this.RENDERER_HEIGHT = (this.BANK_Y_START + 3) * this.LETTER_HEIGHT;
    },
    BUTTON_TEXT_STYLE: {
        font: '50px monospace',
        fill: '#ffffff',
        align: 'center',
        stroke: '#ffffff',
        strokeThickness: 1
    },
    MESSAGE_TEXT_STYLE: {
        font: '15px monospace',
        fill: '#ffffff',
        align: 'center',
        stroke: '#ff07a0',
        strokeThickness: 1
    },
    TEXT_STYLE: {
        font: '100px monospace',
        fill: '#ffffff',
        align: 'center',
        stroke: '#ff07a0',
        strokeThickness: 2
    },
    LETTER_STYLE: {
        font: '50px monospace',
        fill: '#3e1707',
        align: 'center',
        stroke: '#0e0700',
        strokeThickness: 2
    },
    LETTER_STYLE_CORRECT: {
        font: '50px monospace',
        fill: '#00796b',
        align: 'center',
        stroke: '#33691e',
        strokeThickness: 2
    },
    LETTER_STYLE_HALF_CORRECT: {
        font: '50px monospace',
        fill: '#6d4c41',
        align: 'center',
        stroke: '#3e2723',
        strokeThickness: 2
    },

    LETTER_STYLE_INCORRECT: {
        font: '50px monospace',
        fill: '#d50000',
        align: 'center',
        stroke: '#b71c1c',
        strokeThickness: 2
    },
    _drawText: function(text, x, y, scale, offset, callback) {
        var messageText = new PIXI.Text(text,this.TEXT_STYLE);
        messageText.position.x = x;
        messageText.position.y = y;
        messageText.anchor.set(0.5, 0.5);
        messageText.scale.x = scale;
        messageText.scale.y = scale;
        this.applyEffect('appear', messageText, {
            duration: 1000,
            offset: offset,
            callback: callback
        });
        this.stage.addChild(messageText);
    },

    _drawButton: function(text, x, y, callback) {
        var scale = this.SCALE_FACTOR;
        var messageText = new PIXI.Text(text,this.BUTTON_TEXT_STYLE);
        messageText.scale.x = scale;
        messageText.scale.y = scale;
        messageText.position.x = x;
        messageText.position.y = y;
        messageText.anchor.set(0.5, 0.5);
        var graphics = new PIXI.Graphics();

        graphics.beginFill(0x009688);
        graphics.lineStyle(4, 0x009688, 1);
        var w = messageText.width + (this.LETTER_SCALED_WIDTH / 4);
        var h = messageText.height + (this.LETTER_SCALED_HEIGHT / 4);
        graphics.drawRect(x - (w / 2), y - (h / 2), w, h);
        graphics.endFill();

        graphics.interactive = true;
        graphics.buttonMode = true;

        // Add a hit area..
        graphics.hitArea = new PIXI.Rectangle(x - (w / 2),y - (h / 2),w,h);
        graphics.click = callback;
        graphics.touchend = callback;
        graphics.touchendoutside = callback;

        graphics.addChild(messageText);

        this.stage.addChild(graphics);

    },
    getTile: function(url) {
        var texture = PIXI.utils.TextureCache[url];
        if (!texture) {
            throw "texture " + url + " is not in TextureCache";
        }
        var result = new PIXI.Sprite(texture);
        result.width = this.LETTER_SCALED_WIDTH;
        result.height = this.LETTER_SCALED_HEIGHT;
        result.anchor.set(0.5, 0.5);
        return result;
    },

    loadProgressHandler: function(e) {},

    applyEffect: function(prop, tile, duration, offset, options) {
        this.effects[prop].apply(tile, duration, offset, options);
    },

    renderView : function(callback){
         Framework.BaseView.prototype.renderView.call(this, callback);
    },

    setup: function() {
        if (!this.renderer) {
            this.stage = new PIXI.Container();
            this.renderer = PIXI.autoDetectRenderer(this.RENDERER_WIDTH, this.RENDERER_HEIGHT, {
                transparent: true
            });
        }
        this.$el.empty();
        this.$el.append(this.renderer.view);
        this.adjustToDeviceResolution();
        if(!this._animationFrameRequested){
            this._animationFrameRequested = true;
            requestAnimationFrame(this._animationFrame.bind(this));

        }

    },

    adjustToDeviceResolution: function() {
        var iw = window.innerWidth;
        var w = iw < this.RENDERER_WIDTH ? iw : this.RENDERER_WIDTH;
        var nh = (window.innerHeight - ($('.navbar-fixed').height() + 10 ) );
        var h = nh < this.RENDERER_HEIGHT ? nh : this.RENDERER_HEIGHT;
        var sh = h / (this.RENDERER_HEIGHT);
        var sw = w / (this.RENDERER_WIDTH);
        var sf = (sh < sw) ? sh : sw;
        this.SCALE_FACTOR = sf;
        this.LETTER_SCALED_WIDTH = this.LETTER_WIDTH * sf;
        this.LETTER_SCALED_HEIGHT = this.LETTER_HEIGHT * sf;
        this.renderer.resize(w, h);
        this.stage.position.x = this.LETTER_SCALED_WIDTH / 2;
        this.stage.position.y = this.LETTER_SCALED_HEIGHT / 2;
        this.stage.position.y += 10;
        if(this._currentGridWidth){
            var offsetx = (w - (this.LETTER_SCALED_WIDTH * this._currentGridWidth))/2;
            this.stage.position.x += offsetx;
        }



    },

    preloadDataAsync: function(callback) {
        var after = function() {

            callback();
        }
        .bind(this);
        if (this.resources && this.resources.length > 0 && !this.loaded) {
            PIXI.loader.add(this.resources).on("progress", this.loadProgressHandler.bind(this)).load(function() {
                this.loaded = true;
                this.setup();
                callback();
                after();
            }
            .bind(this));
        } else {
            this.setup();
            callback();
        }

    },

    animate: function(delta) {},

    _renderEffects: function(delta) {
        for (var prop in this.effects) {
            this.effects[prop].renderBatch(delta);
        }
    },

    clear: function() {},
    _animationFrame: function() {
        var _ts = Date.now();
        if (!this._ts) {
            this._delta = 0;
        } else {
            this._delta = _ts - this._ts;
        }
        this._ts = _ts;
        this._renderEffects(this._delta);
        this.animate(this._delta);

        requestAnimationFrame(this._animationFrame.bind(this));
        this.renderer.render(this.stage);
    },
    render: function() {
        this.$('canvas').css('display', 'block');
        this.$('canvas').css('padding-left', '0');
        this.$('canvas').css('padding-right', '0');
        this.$('canvas').css('margin-left', 'auto');
        this.$('canvas').css('margin-right', 'auto');
    }
});

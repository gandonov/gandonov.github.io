ScrabwordBoardView = SnapGridBoardView.extend({
    validationCheckMarks: localStorage.validationCheckMarks || false,
    validationLetterHighlight: localStorage.validationLetterHighlight || true,
    initialize: function(options) {
        SnapGridBoardView.prototype.initialize.call(this, options);
        this.listenTo(this.getParent(), 'giveup', this.onGiveUp.bind(this));
        this.listenTo(this.getParent(), 'reloadGameView', this.renderView.bind(this));
        this.listenTo(this.getParent(), 'hintbomb', this.onHintBomb.bind(this));
    },
    _ordinalSuffixOf: function(i) {
        var j = i % 10
          , k = i % 100;
        if (j == 1 && k != 11) {
            return i + "st";
        }
        if (j == 2 && k != 12) {
            return i + "nd";
        }
        if (j == 3 && k != 13) {
            return i + "rd";
        }
        return i + "th";
    },
    getValidationTile: function(isValid) {
        return this.getTile(isValid ? 'sprite_0' : 'sprite_3');
    },

    getCurrentSolution: function() {
        var letterMap = {};
        var tileMap = {};
        var letterTiles = this.letterTiles.concat(this.hintTiles);
        for (var i = 0, l = letterTiles.length; i < l; i++) {
            var tile = letterTiles[i];
            letterMap[tile._boardX + '_' + tile._boardY] = tile._letter;
        }
        var result = [];
        for (var i = 0, l = this.tileStr.length; i < l; i += 4) {
            var word = "";
            var v = Number(this.tileStr[i]);
            var x = Number(this.tileStr[i + 1]);
            var y = Number(this.tileStr[i + 2]);
            var len = Number(this.tileStr[i + 3]);
            var discard = false;
            for (var j = 0; j < len; j++) {
                var tx = x + j * !v;
                var ty = y + j * v;
                var letter = letterMap[tx + '_' + ty];
                if (letter) {
                    word += letter;
                } else {
                    discard = true;
                    break;
                }
            }
            result.push(discard ? null : word);
        }
        return result;
    },

    validateSolution: function(solution) {
        throw "validateSolution must be implemented!";
    },
    onDone: function() {

        this._preloadData.index = this._preloadData.index || 0;
        this._preloadData.index++;

        if (this._preloadData.boards.length > this._preloadData.index) {
            this.loadBoard(this._preloadData.boards[this._preloadData.index], this._preloadData.options[this._preloadData.index]);
        } else {
            this._clearMessage();
            this.onLevelComplete();
        }
    },
    throwText: function(text, callback) {
        if (this.pixiText) {
            this.stage.removeChild(this.pixiText);
        }
        this.pixiText = new PIXI.Text(text,this.TEXT_STYLE);
        this.pixiText.scale.x = 0.8;
        this.pixiText.scale.y = 0.8;
        this.pixiText.position.x = (this.renderer.width / 2) - (this.LETTER_SCALED_WIDTH / 2);
        this.pixiText.position.y = this.renderer.height / 2;
        this.pixiText.anchor.set(0.5, 0.5);
        //this.destructionText.alpha = 0.2;
        this.stage.addChild(this.pixiText);
        this.applyEffect('largify', this.pixiText, {
            callback: function(tile) {
                this.stage.removeChild(tile);
                callback && callback();
            }
            .bind(this),
            duration: 1000
        });
    },
    _clearValidationTiles: function() {
        this.validationTiles = this.validationTiles || [];
        for (var i = 0, l = this.validationTiles.length; i < l; i++) {
            this.stage.removeChild(this.validationTiles[i]);
        }
        this.validationTiles = [];
        var array = this.letterTiles.concat(this.hintTiles);
        for (var i = 0, l = array.length; i < l; i++) {
            var tile = array[i];
            var pixiText = tile.children[0];
            if (pixiText && pixiText.updateText) {
                pixiText.style = this.LETTER_STYLE;
                pixiText.updateText();
            }

        }
    },
    _handleInvalidSolutionAnimation: function(validation, lastPlacedTile) {
        this._clearValidationTiles();
        var tileMap = this._getTileMap();
        for (var i = 0, l = validation.length; i < l; i++) {
            var code = validation[i];
            if (code != 0) {
                var tile = this.getValidationTile(code == 1);
                var v = Number(this.tileStr[i * 4]);
                var x = Number(this.tileStr[i * 4 + 1]);
                var y = Number(this.tileStr[i * 4 + 2]);
                var len = Number(this.tileStr[i * 4 + 3]);
                this.putTile(tile, x + !v * len, y + v * len);
                if (this.validationLetterHighlight) {
                    for (var j = 0; j < len; j++) {
                        var t = tileMap[(x + (j * !v)) + '_' + (y + (j * v))];
                        var letterSprite = t.children[0];
                        if (code == 1) {
                            var style = (letterSprite.style == this.LETTER_STYLE || letterSprite.style == this.LETTER_STYLE_CORRECT) ? this.LETTER_STYLE_CORRECT : this.LETTER_STYLE_HALF_CORRECT;
                            letterSprite.style = style;
                        } else {
                            var style = (letterSprite.style == this.LETTER_STYLE || letterSprite.style == this.LETTER_STYLE_INCORRECT) ? this.LETTER_STYLE_INCORRECT : this.LETTER_STYLE_HALF_CORRECT;
                            letterSprite.style = style;
                        }
                        letterSprite.updateText();
                    }
                }
                if (lastPlacedTile) {
                    if (code == 1 && (v && lastPlacedTile._boardX == x && lastPlacedTile._boardY < (y + len) && lastPlacedTile._boardY >= y) || (!v && lastPlacedTile._boardY == y && lastPlacedTile._boardX < (x + len) && lastPlacedTile._boardX >= x)) {
                        for (var j = 0; j < len; j++) {
                            var t = tileMap[(x + (j * !v)) + '_' + (y + (j * v))];
                            var letterSprite = t.children[0];
                            this.applyEffect('highlight', t, {
                                offset: j * 40,
                                duration: 600,
                                intensity: 0.4
                            });
                        }
                    }
                }
                if (this.validationCheckMarks) {
                    this.validationTiles.push(tile);
                }
            }
        }
        for (var i = 0, l = this.validationTiles.length; i < l; i++) {
            var tile = this.validationTiles[i];
            this.stage.addChild(tile);
        }
    },
    _getTileMap: function() {
        var tileMap = {};
        var letterTiles = this.letterTiles.concat(this.hintTiles);
        for (var i = 0, l = letterTiles.length; i < l; i++) {
            var tile = letterTiles[i];
            tileMap[tile._boardX + '_' + tile._boardY] = tile;
        }
        return tileMap;
    },
    _handleValidSolutionAnimation: function(text, callback) {
        this._clearValidationTiles();
        app.playSound('complete');
        this.validationTiles = this.validationTiles || [];
        for (var i = 0, l = this.validationTiles.length; i < l; i++) {
            this.stage.removeChild(this.validationTiles[i]);
        }
        var letterTiles = this.letterTiles.concat(this.hintTiles);
        for (var i = 0, l = letterTiles.length; i < l; i++) {
            var tile = letterTiles[i];
            this.applyEffect('highlight', letterTiles[i], {
                duration: 1000,
                intensity: 1.5
            });
        }
        if (this._preloadData.index == this._preloadData.boards.length - 1) {
            this._explodeLetters();
        }

        if (this.messageText) {
            this.stage.removeChild(this.messageText);
        }
        this.throwText(text, callback);
    },
    validate: function(lastTile) {
        var solution = this.getCurrentSolution();
        var validation = this.validateSolution(solution);
        var valid = true;
        for (var i = 0, l = validation.length; i < l; i++) {
            if (validation[i] != 1) {
                valid = false;
            }
        }
        if (valid) {
            if (this.timerBar) {
                this.stage.removeChild(this.timerBar);
            }
            this.endTime = Date.now() - this.startTime;
            this._endTimes.push(this.endTime);
            this._solution.push(solution);
            var text = this.messageOnComplete || 'complete';
            $('#giveUp').addClass('hide');
            this._handleValidSolutionAnimation(text, this.onDone.bind(this));
        } else {
            this._handleInvalidSolutionAnimation(validation, lastTile);
        }
    },

    _labelize: function(letter) {
        var character = letter;
        if (character == '/') {
            character = '\u00f7';
        }
        if (character == '*') {
            character = '\u00d7';
        }
        return character;
    },
    _getPIXICharacter: function(letter, style) {
        var character = this._labelize(letter.toUpperCase());
        var pixiCharacter = new PIXI.Text(character,style);
        pixiCharacter.pivot.x = 16;
        pixiCharacter.pivot.y = 24;
        switch (character) {
        case '=':
            //pixiCharacter.pivot.y = 25;
            break;
        default:
            break;
        }
        return pixiCharacter;
    },
    _stampFloorTile: function(tile, letter) {
        var l = this._getPIXICharacter(letter, this.LETTER_STYLE);
        l.alpha = 0.6;
        tile.removeChildren();
        tile.addChild(l);
    },

    HINT_SPRITE: 'sprite_5',
    AFFIXED_SPRITE: 'sprite_2',
    _showHint: function(tile, showPaw) {
        if (tile._hinted) {
            return;
        } else {
            tile._hinted = true;
        }

        if (showPaw) {
            var paw = this.getTile(this.HINT_SPRITE);
            paw.alpha = 0.8;
            this.applyEffect('paw', paw, {
                duration: 40000
            });
            tile.addChild(paw);
            //bring to front
            this.stage.removeChild(tile);
            this.stage.addChild(tile);
        }
        this._setMessageText('fetching hint...');

        this._preloadData.hintsLeft--;

        this.getHint(tile, function(letter) {

            localStorage.hintHasBeenUsed = "true";
            this._setMessageText('fetching solution...');
            if (letter || letter === 0) {
                app.playSound('hintBomb');
                var toAffix = null;
                for (var i = 0, l = this.letterTiles.length; i < l; i++) {
                    var t = this.letterTiles[i];
                    if (!t._affixed && t._letter == letter) {
                        if (!toAffix || toAffix._boardY < t._boardY) {
                            toAffix = t;

                        }
                    }
                }
                toAffix.interactive = false;
                toAffix._affixed = true;
                toAffix.texture = PIXI.utils.TextureCache[this.AFFIXED_SPRITE];

                this.stage.removeChild(toAffix);
                this.stage.addChild(toAffix);
                this.applyEffect('highlight', toAffix, {
                    intensity: 1.3
                });
                this.putTile(toAffix, tile._boardX, tile._boardY, true);
                this.validate(toAffix);
                tile.removeChildren();
                //this._stampFloorTile(tile, letter);
            } else {
                this.applyEffect('smallify', tile, {
                    duration: 1000,
                    callback: function(t) {
                        this.stage.removeChild(t);
                    }
                    .bind(this)
                });
            }

            this._setMessage();
        }
        .bind(this), function(data) {
            tile.removeChildren();
            Materialize.bonita("unable to connect to server...", 2000);
            this._preloadData.hintsLeft++;
            // roll back
            this._setMessage();

        }
        .bind(this));
    },
    onHintBomb: function() {
        this._preloadData.hintBombsLeft--;
        Materialize.bonita("boom!", 1000);
        var chosen = {};
        for (var i = 0, l = this.floorTiles.length; i < l; i += 2) {
            var tile = this.floorTiles[i];
            var letter = app.puzzleGenerator.getIntendedSolutionLetterAt(this.board, tile._boardX, tile._boardY);
            chosen[letter] = chosen[letter] || [];
            chosen[letter].push({
                x: tile._boardX,
                y: tile._boardY
            });
            tile.removeChildren();
            //this._stampFloorTile(tile, letter);
        }
        for (var i = 0, l = this.letterTiles.length; i < l; i++) {
            var tile = this.letterTiles[i];
            if (chosen[tile._letter]) {
                var loc = chosen[tile._letter].pop();
                if (chosen[tile._letter].length == 0) {
                    delete chosen[tile._letter];
                }
                var letterSprite = tile.children[0];
                var newStyle = _.clone(letterSprite.style);
                newStyle.fill = "#00796b";
                letterSprite.style = newStyle;
                letterSprite.updateText();
                this.putTile(tile, loc.x, loc.y, true);
                this.applyEffect('highlight', tile, {
                    intensity: 1.2
                });
            } else {
                this.putBackInBank(tile);
            }
        }
        this.validate();
    },
    onFloorTileDoubleTap: function(tile) {
        this._preloadData.hintsLeft = this._preloadData.hintsLeft || 0;
        if (this._preloadData.hintsLeft <= 0 || this.nohints) {
            return;
        }
        this._setMessage();
        this._showHint(tile, true);
    },

    getHint: function(tile, callback, error) {
        if (!this.unshuffled) {
            var index = this._preloadData.index;
            var position = -1;
            for (var i = 0, l = this.floorTiles.length; i < l; i++) {
                if (this.floorTiles[i] == tile) {
                    position = i;
                    break;
                }
            }
            var client = JSON.parse(localStorage.client);
            this.postJSON(WQConfig.urls.api, function(data) {
                if (data.errorMessage) {
                    error(data.errorMessage);
                } else {
                    callback(data.letter);
                }
            }
            .bind(this), error, {
                clientid: client.clientid,
                product: WQConfig.product,
                operation: "Hint",
                data: {
                    index: index,
                    position: position,
                    x: tile._boardX,
                    y: tile._boardY
                }
            });
        } else {
            setTimeout(function() {
                if (tile._letterTile) {
                    callback(tile._letterTile._letter);
                } else {
                    callback(null);
                }
            }
            .bind(this), 300);

        }

    },

    _transformToHint: function(tile) {
        tile.texture = PIXI.utils.TextureCache[this.AFFIXED_SPRITE];
    },

    showSolution: function(callback, error) {
        this._clearValidationTiles();
        this._clearMessage();
        this._setMessageText('fetching solution...');
        for (var i = 0, l = this.letterTiles.length; i < l; i++) {
            var tile = this.letterTiles[i];
            tile.interactive = false;
            this._transformToHint(tile);
            //bring to front
            this.stage.removeChild(tile);
            this.stage.addChild(tile);
        }
        for (var i = 0, l = this.floorTiles.length; i < l; i++) {
            var tile = this.floorTiles[i];
            this.stage.removeChild(tile);
        }
        var after = function() {
            for (var prop in this.floorTileMap) {
                var tile = this.floorTileMap[prop];
                if (tile._letterTile) {
                    this.applyEffect('highlight', tile._letterTile, {
                        duration: 500,
                        intensity: 0.5
                    });
                    this.putTile(tile._letterTile, tile._boardX, tile._boardY, true);
                }

            }
            callback();
        }
        .bind(this);
        if (this.unshuffled) {
            after();
        } else {
            this._getLetters(this._preloadData.index, after, error);
        }
    },

    bindSolutionToFloorTiles: function(data) {

        for (var i = 0, l = this.floorTiles.length; i < l; i++) {
            var tile = this.floorTiles[i];
            if (!tile._letterTile) {
                tile._letterTile = this.letterTileMap[data.letters[i]].pop();
            }
        }

    },
    _getLetters: function(index, success, error) {
        var client = JSON.parse(localStorage.client);
        this.postJSON(WQConfig.urls.api, function(data) {
            if (data.errorMessage) {
                error(data.errorMessage);
            } else {
                this.bindSolutionToFloorTiles(data);
                success(data);
            }
        }
        .bind(this), error, {
            clientid: client.clientid,
            product: WQConfig.product,
            operation: "Forfeit",
            data: {
                index: index
            }
        });

    },
    _handleError: function(err) {
        this._setMessageText(err);
    },
    FLOOR_TILE_SPRITE: 'sprite_1',
    getFloorTile: function() {
        var result = this.getTile(this.FLOOR_TILE_SPRITE);
        var that = this;
        var mouseup = function(e) {
            if (this.children && this.children.length > 0) {
                return;
            }
            if (this.__lastTap && (this.__lastTap + 500 > Date.now())) {
                delete this.__lastTap;
                that.onFloorTileDoubleTap(this);
            } else {
                that.applyEffect('highlight', this, {
                    duration: 500
                });
                this.__lastTap = Date.now();
            }
        }
        result.interactive = true;
        if (app.isBrowser) {
            result.mouseup = mouseup;
            result.mouseupoutside = mouseup;
            result.touchend = mouseup;
            result.touchendoutside = mouseup;
        } else {
            result.touchend = mouseup;
            result.touchendoutside = mouseup;
        }
        return result;
    },
    _getTextedTile: function(letter, draggable, style) {
        var tile = draggable ? this.getDraggableTile('sprite_4') : this.getTile(this.AFFIXED_SPRITE);
        tile.addChild(this._getPIXICharacter(letter, style || this.LETTER_STYLE));
        tile._letter = letter;
        return tile;
    },
    getHintTile: function(letter) {
        return this._getTextedTile(letter);
    },
    _clearHoverEffects: function() {
        for (var prop in this.floorTileMap) {
            this.floorTileMap[prop].scale.x = this.SCALE_FACTOR;
            this.floorTileMap[prop].scale.y = this.SCALE_FACTOR;
        }
        for (var i = 0, l = this.letterTiles.length; i < l; i++) {
            this.letterTiles[i].tint = 16777215;
        }
    },
    getLetterTile: function(letter) {
        var that = this;
        var tile = this._getTextedTile(letter, true);
        tile.onHover = function(x, y) {
            that._clearHoverEffects();
            var floorTile = that.floorTileMap[x + "_" + y];
            if (floorTile) {
                floorTile.scale.x = that.SCALE_FACTOR * 1.1;
                floorTile.scale.y = that.SCALE_FACTOR * 1.1;
                app.playSound('hovertile');
                that.applyEffect('highlight', floorTile, {
                    duration: 400
                });
            }
            for (var i = 0, l = that.letterTiles.length; i < l; i++) {
                var lt = that.letterTiles[i];
                if (this != lt && lt.interactive && lt._boardX == x && lt._boardY == y) {
                    lt.tint = 0x3FFCDC;
                }
            }
        }
        tile.onDropTile = function(x, y, sx, sy, outOfBounds) {
            that._clearHoverEffects();
            if (outOfBounds) {
                app.playSound('wood');
                that.putBackInBank(this);
            } else {
                var floorTile = that.floorTileMap[x + "_" + y];
                if (floorTile) {
                    // last check -- if there is a letter there already, swap them
                    var onFixed = false;
                    var bumpUp = null;
                    for (var i = 0, l = that.letterTiles.length; i < l; i++) {
                        var lt = that.letterTiles[i];
                        if(that._currentGridHeight && that._currentGridHeight <= lt._boardY){
                             bumpUp = lt;
                        }else if(!that._currentGridHeight && (lt._boardY > that.BANK_Y_START + 2)) {
                            bumpUp = lt;
                        }
                        if (this != lt && lt._boardX == x && lt._boardY == y) {
                            // when hint is used, and letter became "fixed..." extra logic
                            // since there is floor tile underneath it. 
                            if (!lt.interactive) {
                                onFixed = true;
                            } else {
                                that.putTile(lt, sx, sy, true);
                            }
                            break;
                        }
                    }

                    if (onFixed) {
                        that.putBackInBank(this);
                        app.playSound('wood');
                    } else {
                        that.putTile(this, x, y);
                        app.playSound('placetile');
                        if (bumpUp) {
                            that.putBackInBank(bumpUp);
                        }
                    }
                } else {
                    that.putBackInBank(this);
                    app.playSound('wood');
                }
            }
            that.validate(this);
        }
        tile.onIllegalPlacement = function(x, y) {
            app.playSound('wood');
            that.putBackInBank(this);
            that.validate(this);
        }
        return tile;
    },

    TUTORIAL_COMPLETE_MESSAGES: ["Equations Go From\nLeft To Right And Top To Bottom.", "Equality Sign Can Be Anywhere\nWithin The Equation.", "Double Tap An Empty Tile\nTo Reveal a Hint.", ],
    tutorialComplete: function() {

        localStorage.tutorialComplete = "true";

        var x = (this.renderer.width / 2) - (this.LETTER_SCALED_WIDTH / 2);
        var y = this.LETTER_SCALED_HEIGHT * (1);
        var text = "TUTORIAL COMPLETE";
        this._drawText(text, x, y, 0.3);
        for (var i = 0, l = this.TUTORIAL_COMPLETE_MESSAGES.length; i < l; i++) {
            y += (this.LETTER_SCALED_HEIGHT * 1.5);
            text = this.TUTORIAL_COMPLETE_MESSAGES[i];
            this._drawText(text, x, y, 0.15);
        }
        y += (this.LETTER_SCALED_HEIGHT * 2);

        this._drawButton("I'm Ready", x, y, function() {
            this.renderView();
        }
        .bind(this));

    },

    _dailyChallengeComplete: function() {

        this._setMessageText("contacting server...");
        var client = JSON.parse(localStorage.client);
        this.postJSON(WQConfig.urls.api, function(data) {

            if (data.errorMessage) {
                app.log('error from server on Submit:' + data.errorMessage, 'error');
                this._setMessageText("error contacting server!");
            } else {
                this._clearMessage();
                var x = (this.renderer.width / 2) - (this.LETTER_SCALED_WIDTH / 2);
                var y = this.LETTER_SCALED_HEIGHT * (1);

                var text = "";
                if (data.stats) {
                    var rankStr = this._ordinalSuffixOf(Number(data.stats.place));
                    text = "Place:      ";
                    text = text.substr(0, text.length - rankStr.length);
                    text += rankStr;
                } else {
                    text = "COMPLETED";
                }

                y += (this.LETTER_SCALED_HEIGHT * 1);
                if (data.stats) {
                    text = "new best time:      ";
                } else {
                    text = "best time:      ";
                }
                var bestTimeStr = data.result.bestTime + "s";
                text = text.substr(0, text.length - bestTimeStr.length);
                text += bestTimeStr;
                this._drawText(text, x, y, 0.18);

                if (data.stats) {

                    if (data.stats.total == 1) {
                        text = "You are the only one\n who played today."
                    } else {
                        var percentage = (Math.round(100 - ((data.stats.place - 1) / (data.stats.total - 1)) * 100));
                        if (percentage > 0) {
                            text = "You did better than " + percentage + "%\n" + " of " + (data.stats.total - 1) + " other players."
                        } else {
                            text = "Thank you for playing!"
                        }
                    }

                    y += (this.LETTER_SCALED_HEIGHT * 1);
                    this._drawText(text, x, y, 0.18);
                } else {
                    y += (this.LETTER_SCALED_HEIGHT * 0.70);
                    text = "this time:      ";
                    var timeStr = data.result.attemptTime + "s";
                    text = text.substr(0, text.length - timeStr.length);
                    text += timeStr;
                    this._drawText(text, x, y, 0.18);
                }

                y += (this.LETTER_SCALED_HEIGHT * 1.5);

                this._drawButton("TOP 50", x, y, function() {
                    app.mainView.fromScoresHack = true;
                    this.setParameters({
                        bm: null,
                        mv: 'scoreListView'
                    });
                }
                .bind(this));

                y += (this.LETTER_SCALED_HEIGHT * 1.5);

                this._drawButton("PLAY AGAIN", x, y, function() {
                    this.renderView();
                }
                .bind(this));

            }
        }
        .bind(this), function() {
            app.log('error from server on Submit!', 'error');
            this._setMessageText("error contacting server!");
        }
        .bind(this), {
            clientid: client.clientid,
            product: WQConfig.product,
            operation: "Submit",
            data: {
                solution: this._solution
            }
        });

    },

    _soloComplete: function() {
        var x = (this.renderer.width / 2) - (this.LETTER_SCALED_WIDTH / 2);
        var y = this.LETTER_SCALED_HEIGHT * (1);
        var text = "STAGE COMPLETE";
        this._drawText(text, x, y, 0.3);
        y += (this.LETTER_SCALED_HEIGHT * 1.5);

        var totalTime = 0;
        for (var i = 0, l = this._preloadData.options.length; i < l; i++) {
            var o = this._preloadData.options[i];
            totalTime += o.originalTime || o.time || 0;
        }
        totalTime *= 1000;
        var usedTime = 0;

        for (var i = 0, l = this._endTimes.length; i < l; i++) {
            var o = this._endTimes[i];
            usedTime += o || 0;
        }

        var percentageLeft = ((totalTime) - usedTime) / totalTime;
        var score = 1;
        if (percentageLeft > .5) {
            score = 3
        } else if (percentageLeft > .3) {
            score = 2;
        }
        var scores = JSON.parse(localStorage.scores);
        var index = this.getParameter('l') - 1;
        if (!scores[index] || score > scores[index]) {
            scores[index] = score;
        }
        localStorage.scores = JSON.stringify(scores);

        text = "\u2605 ";
        text += score > 1 ? "\u2605 " : "\u2606 ";
        text += score > 2 ? "\u2605 " : "\u2606 ";

        this._drawText(text, x, y, 0.3);
        y += (this.LETTER_SCALED_HEIGHT * 2);

        this._drawButton("DONE", x, y, function() {
            app.mainView.onBack();
        }
        .bind(this));
    },

    onLevelComplete: function() {
        if (localStorage.tutorialComplete == 'false') {
            this.tutorialComplete();
        } else if (this.getParameter('l') != null) {
            this._soloComplete();
        } else {
            this._dailyChallengeComplete();
        }
    },

    generateRandomBoard: function(options, generator) {
        return "generateRandomBoard must be implemented";
    },

    generateLevel: function(level) {
        var result = {};
        result.hints = level.hints;
        result.time = level.time;
        result.boards = [];
        result.options = [];
        var boards = level.boards;

        var bg = new BoardGenerator();

        for (var i = 0, l = boards.length; i < l; i++) {
            var board = boards[i];
            var options = {};
            if (board.dynamic) {
                var generated = this.generateRandomBoard(board.dynamic, bg);
                result.boards.push(bg.boardToString(generated));
            } else {

                result.boards.push(bg.boardToString(board));
            }
            options.unshuffled = true;
            options.message = board.message;
            options.messageOnComplete = board.messageOnComplete;
            options.nohints = board.nohints;
            options.time = board.time || 0;
            result.options.push(options);
        }
        return result;
    },

    preloadDataAsync: function(callback, error) {
        SnapGridBoardView.prototype.preloadDataAsync.call(this, function(data) {
            var onError = function(err) {
                this._setMessageText("error while loading resoureces.");
            }
            .bind(this);
            $('#giveUp').addClass('hide');
            $('#reloadGameView').addClass('hide');
            if (this.stage) {
                this.stage.removeChildren();
            }
            this._setMessageText("Loading...");
            if (localStorage.tutorialComplete == "false") {
                callback(this.generateLevel(WQConfig.tutorial));
            } else if (this.getParameter('l') != null) {
                var levels = JSON.parse(localStorage.campaign);
                var level = Number(this.getParameter('l'));
                var index = level - 1;
                var level = levels[index];
                var perks = null;
                if (index > 0) {
                    var previous = levels[index - 1];
                    var scores = JSON.parse(localStorage.scores);
                    var score = scores[index - 1];
                    perks = previous.bonuses && previous.bonuses.slice(0, score);

                }
                callback(this.generateLevel(level, perks));
            } else {
                var client = JSON.parse(localStorage.client);
                this.postJSON(WQConfig.urls.api, function(data) {
                    callback(data);
                }
                .bind(this), onError, {
                    clientid: client.clientid,
                    product: WQConfig.product,
                    operation: "Attempt"
                });
            }

        }
        .bind(this), error);

    },

    loadBoard: function(board, options) {

        options = options || {};
        this.startTime = Date.now();
        this.stage.removeChildren();
        this.message = options.message;
        this.messageOnComplete = options.messageOnComplete;
        this.nohints = options.nohints;
        this.unshuffled = options.unshuffled;
        var entries = board.entries;
        var index = Number(board[0]) * 4;
        this.tileStr = board.substr(1, index);
        //         this.scaleToGridDimensions(7, 12);
        this.floorTiles = [];
        this.floorTileMap = {};
        this.letterTileMap = {};
        this.letterTiles = [];
        var lettersUsed = {};
        this.hintTiles = [];
        var used = {};
        this.validationTiles = [];
        var fc = parseInt(board[++index], 16);
        for (var i = 0; i < fc; i++) {
            var x = Number(board[++index]);
            var y = Number(board[++index]);
            var c = board[++index];
            used[x + "_" + y] = true;
            var tile = this.getHintTile(c);
            this.hintTiles.push(tile);
            this.stage.addChild(tile);
            this.putTile(tile, x, y);
        }
        var li = 0;
        var lo = ++index;
        for (var i = 0, l = this.tileStr.length; i < l; i += 4) {
            var v = Number(this.tileStr[i]);
            var x = Number(this.tileStr[i + 1]);
            var y = Number(this.tileStr[i + 2]);
            var len = Number(this.tileStr[i + 3]);
            for (var j = 0; j < len; j++) {
                var tx = x + j * !v;
                var ty = y + j * v;
                var key = tx + "_" + ty;
                if (!used[key]) {
                    var tile = this.getFloorTile();
                    this.floorTiles.push(tile);
                    this.floorTileMap[key] = tile;
                    this.stage.addChild(tile);
                    this.putTile(tile, tx, ty);
                    var letter = board[lo + li];
                    var letterTile = this.getLetterTile(letter);
                    li++;
                    this.letterTiles.push(letterTile);
                    if (!this.letterTileMap[letter]) {
                        this.letterTileMap[letter] = [];
                    }
                    this.letterTileMap[letter].push(letterTile);
                    this.stage.addChild(letterTile);

                    if (this.unshuffled) {
                        tile._letterTile = letterTile;
                    }
                }
                used[key] = true;
            }
        }
        /**
         * Randomize array element order in-place.
         * Using Durstenfeld shuffle algorithm.
         */
        for (var i = this.letterTiles.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));

            var temp = this.letterTiles[i];
            this.letterTiles[i] = this.letterTiles[j];
            this.letterTiles[j] = temp;
        }
        for (var i = 0, l = this.letterTiles.length; i < l; i++) {
            var tile = this.letterTiles[i];
            this.putBackInBank(tile, true);
        }
        this._setMessage();
        $('#giveUp').removeClass('hide');
        this.applyEffect('appear', this.stage, {
            duration: 500
        });
        if (options.time) {
            this.startTimer(1000 * options.time);
        }
        this.validate();
    },

    render: function(callback) {
        SnapGridBoardView.prototype.render.call(this, callback);
        if (this.getParameter('bm') == 'ranked') {
            $('#totalLevelStars').html('DC');
        } else {
            $('#totalLevelStars').html(localStorage.level);
        }

        this._preloadData.index = this._preloadData.index || 0;
        this._preloadData.hintsLeft = this._preloadData.hints || 0;
        this._solution = [];
        this._endTimes = [];
        this._preloadData.options = this._preloadData.options || [];
        if (this._preloadData.hintsLeft && localStorage.hintHasBeenUsed == "false") {
            Materialize.bonita("Double-Tap on Empty Tile!", 3000);
        }
        this.loadBoard(this._preloadData.boards[this._preloadData.index], this._preloadData.options[this._preloadData.index]);
    }

});

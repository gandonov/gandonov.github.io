SnapGridBoardView = SpriteBoardView.extend({
    effects: {
        'disperse': new DisperseEffect(),
        'largify': new LargifyEffect(),
        'smallify': new SmallifyEffect(),
        'highlight': new HighlightEffect(),
        'flyto': new FlyToEffect(),
        'appear': new AppearEffect(),
        'paw': new PawEffect(),
        'timerBar': new TimerBarEffect()
    },

    USEFUL_MESSAGES: ["Remember, you have some hints\n Double-Tap floor tiles to use them!", "Perhaps try replaying previous stage?\n It may improve your chances here."],
    _clearMessage: function() {
        if (this.messageText) {
            this.stage.removeChild(this.messageText);
        }
    },
    _setMessageText: function(message) {
        this._clearMessage();
        this.messageText = new PIXI.Text(message,this.MESSAGE_TEXT_STYLE);

        this.messageText.position.x = -this.stage.position.x - (this.messageText.width/2) + (this.renderer.width/2);//this.renderer.width/2;//(this.renderer.width / 2) -  - this.stage.position.x;
        this.messageText.position.y = this.LETTER_SCALED_HEIGHT * (this.BANK_Y_START - 1);
        this.messageText.anchor.set(0.0, 0.5);
        this.stage.addChild(this.messageText);
    },
    _setMessage: function() {
        var hints = this._preloadData.hintsLeft;
        var ltc = this._preloadData.boards.length - this._preloadData.index;
        var msg = this.message || ("puzzles left:  " + ltc + "\nhints left:    " + (hints ? hints : "0"));
        this._setMessageText(msg);
    },

    _explodeLetters: function() {
        var ax = 0;
        var ay = 0;
        var letterTiles = this.letterTiles.concat(this.hintTiles);
        var l = letterTiles.length;
        for (var i = 0; i < l; i++) {
            var tile = letterTiles[i];
            ax += tile.position.x;
            ay += tile.position.y;
        }
        ax = ax / l;
        ay = ay / l;

        for (var prop in this.floorTileMap) {
            this.floorTileMap[prop].alpha = 0;
        }

        for (var i = 0; i < l; i++) {
            var tile = letterTiles[i];
            tile.texture = PIXI.utils.TextureCache['sprite_2'];
            tile.interactive = false;
            var vx = tile.position.x - ax;
            var vy = tile.position.y - ay;
            this.applyEffect('flyto', tile, {
                x: vx * 10,
                y: vy * 10,

                speed: .1,
                spin: .05 * (i % 2 == 0 ? 1 : -1),
                fade: .01,
                callback: function(tile) {
                    this.stage.removeChild(tile);
                }
                .bind(this)
            });
        }

    },
    putBackInBank: function(thisTile, instantly) {
        for (var i = 0; i < 100; i++) {
            var x = (i % this.LETTERS_PER_BANK_ROW);
            var y = this.BANK_Y_START + Math.floor(i / this.LETTERS_PER_BANK_ROW);
            var taken = false;
            for (var j = 0, l = this.letterTiles.length; j < l; j++) {
                var tile = this.letterTiles[j];
                if (thisTile == tile) {
                    continue;
                }
                if (tile._boardX == x && tile._boardY == y) {
                    taken = true;
                    break;
                }
            }
            if (!taken) {
                this.putTile(thisTile, x, y, instantly ? false : true);
                break;
            }
        }
    },
    // utility function for grid snapping
    _calcArea: function(x, y, position) {
        var qx = Math.floor(x / this.LETTER_SCALED_WIDTH);
        var qy = Math.floor(y / this.LETTER_SCALED_HEIGHT);
        if (qy < 0 || qx < 0 || qx >= (this._currentGridWidth || (this.LETTERS_PER_ROW))) {
            return null;
        }
        var qRight = (qx + 1) * this.LETTER_SCALED_WIDTH;
        var qLeft = qx * this.LETTER_SCALED_WIDTH;
        var qTop = qy * this.LETTER_SCALED_HEIGHT;
        var qBottom = (qy + 1) * this.LETTER_SCALED_HEIGHT;
        var lx = -1;
        var ly = -1;
        var area = lx * ly;
        switch (position) {
        case 0:
            lx = qRight - x;
            ly = qBottom - y;
            break;
        case 1:
            lx = x - qLeft;
            ly = qBottom - y;
            break;
        case 2:
            lx = x - qLeft;
            ly = y - qTop;
            break;
        case 3:
            lx = qRight - x;
            ly = y - qTop;
            break;
        default:
            break;
        }
        var area = lx * ly;
        return {
            qx: qx,
            qy: qy,
            area: area
        };
    },
    getDraggableTile: function(url, sprite) {
        var tile = sprite || this.getTile(url);
        tile.interactive = true;
        tile.onDropTile = function(x, y) {}
        tile.onHover = function(x, y, sx, sy) {}
        var that = this;
        var mousedown = function(data) {
            if (this._effects && this._effects["flyto"]) {
                return;
            }
            this.__mx = this.position.x - data.data.global.x;
            this.__my = this.position.y - data.data.global.y;
            this.dragging = true;
            that.stage.removeChild(this);
            that.stage.addChildAt(this, that.stage.children.length);
        }
        if (app.isBrowser) {
            tile.mousedown = mousedown;
            tile.touchstart = mousedown;
        } else {
            tile.mousedown = mousedown;
            tile.touchstart = mousedown;
        }
        var mouseup = function(data) {
            if (this._effects && this._effects["flyto"]) {
                return;
            }
            this.data = null;
            this.dragging = false;
            if (this._currentDrop) {
                var x = this._currentDrop.qx;
                var y = this._currentDrop.qy;
                this.onDropTile(x, y, this._boardX, this._boardY, false);
            } else {
                this.onDropTile(null, null, this._boardC, this._boardY, true);
            }
            this._currentDrop = null;
        }
        if (app.isBrowser) {
            tile.mouseup = mouseup;
            tile.mouseupoutside = mouseup;
            tile.touchend = mouseup;
            tile.touchendoutside = mouseup;
        } else {
            tile.touchend = mouseup;
            tile.touchendoutside = mouseup;
        }
        var mousemove = function(data) {
            if (this._effects && this._effects["flyto"]) {
                return;
            }
            if (that.beginHintMode) {
                return;
            }
            if (this.dragging) {
                var x = this.position.x = data.data.global.x + this.__mx;
                var y = this.position.y = data.data.global.y + this.__my;
                var p = [{
                    x: x,
                    y: y,
                }, {
                    x: x + that.LETTER_SCALED_WIDTH,
                    y: y
                }, {
                    x: x + that.LETTER_SCALED_WIDTH,
                    y: y + that.LETTER_SCALED_HEIGHT
                }, {
                    x: x,
                    y: y + that.LETTER_SCALED_HEIGHT
                }];
                var highest = null;
                for (var i = 0; i < 4; i++) {
                    var q = that._calcArea(p[i].x, p[i].y, i);
                    if ((q && !highest) || (q && highest && highest.area < q.area)) {
                        highest = q;
                    }
                }
                this._currentDrop = highest;
                if (this._currentDrop) {
                    if (that._lhqx != highest.qx || that._lhqy != highest.qy) {
                        this.onHover(highest.qx, highest.qy, that._lhqx, that._lhqy);
                        that._lhqx = highest.qx;
                        that._lhqy = highest.qy;
                    }
                    this._currentDrop.tile = this;
                }
            }
        }
        if (app.isBrowser) {
            tile.mousemove = mousemove;
            tile.touchmove = mousemove;
        } else {
            tile.mousemove = mousemove;
            tile.touchmove = mousemove;
        }
        return tile;
    },
    putTile: function(tile, x, y, smooth, callback) {
        var xoffset = x * this.LETTER_SCALED_WIDTH;
        var yoffset = y * this.LETTER_SCALED_HEIGHT;
        if (!smooth) {
            tile.position.x = xoffset;
            tile.position.y = yoffset;
        } else {
            this.applyEffect('flyto', tile, {
                x: xoffset,
                y: yoffset,
                callback: callback
            });
        }
        tile._boardX = x;
        tile._boardY = y;
    },
    startTimer: function(duration) {
        var y = ((this.BANK_Y_START - 1.5) * this.LETTER_SCALED_HEIGHT) + 3;

        var timerBar = new PIXI.Graphics();
        timerBar.beginFill(0xff07a0);
        timerBar.lineStyle(1, 0xff07a0, 1);
        timerBar.drawRect(-this.LETTER_SCALED_WIDTH, y - 2, 5, 5);
        timerBar.endFill();

        var line = new PIXI.Graphics();
        var linew = (this._currentGridWidth - 0.2) * this.LETTER_SCALED_WIDTH;
        line.beginFill(0xff07a0);
        line.lineStyle(1, 0xff07a0, 1);
        line.drawRect(-this.LETTER_SCALED_WIDTH*0.5, 0, linew, 1);
        line.endFill();
        line.position.y = y + 2;

        var square = new PIXI.Graphics();
        square.lineStyle(1, 0xe9bad9, 1);
        square.beginFill(0xe9bad9);
        square.drawRect(0, 0, 7, 7);
        square.endFill();
        square.position.x = linew - (this.LETTER_SCALED_WIDTH / 2);

        square.pivot.x = square.graphicsData[0].shape.width / 2;
        square.pivot.y = square.graphicsData[0].shape.height / 2;

        line.addChild(square);

        timerBar.addChild(line);
        this.stage.addChild(timerBar);

        if (this.timerBar) {
            this.stage.removeChild(this.timerBar);
        }
        this.timerBar = timerBar;

        this.applyEffect('timerBar', this.timerBar, {
            duration: duration,
            callback: function(tile) {
                if (tile.parent == this.stage) {
                    this.onGiveUp(true);
                }

            }
            .bind(this)
        })
    },
    onGiveUp: function(timedOut) {
        app.playSound('hintBomb');
        $('#giveUp').addClass('hide');
        if (this.timerBar) {
            this.stage.removeChild(this.timerBar);
        }
        this.showSolution(function() {
            this._clearMessage();
            var topPart = !timedOut ? 'Game Over' : 'Out of Time!';
            var msg = topPart + '\nSolution to the puzzle revealed.'
//             if (this.getParameter('l') != null) {
//                 msg += "\n\n";
//                 if (this._preloadData.hintsLeft > 0) {
//                     msg += this.USEFUL_MESSAGES[0];
//                 }
//             }
            this._setMessageText(msg);
            this.applyEffect('appear', this.messageText, {
                duration: 1000,
                callback: function() {
                    var y = (this.LETTER_SCALED_HEIGHT * this.BANK_Y_START) + this.LETTER_SCALED_HEIGHT / 2;
                    var x = (this.renderer.width / 2) - (this.LETTER_SCALED_WIDTH / 2);

                    if (this.getParameter('l') != null) {// some suggestions

                    } else {

                        this._drawButton("TOP 50", x, y, function() {
                            app.mainView.fromScoresHack = true;
                            this.setParameters({
                                bm: null,
                                mv: 'scoreListView'
                            });
                        }
                        .bind(this));

                    }

                    y += (this.LETTER_SCALED_HEIGHT * 1.5);
                    this._drawButton("PLAY AGAIN", x, y, function() {
                        this.renderView();
                    }
                    .bind(this));

                }
                .bind(this)
            });
        }
        .bind(this), this._handleError.bind(this));
    },
    scaleToGridDimensions: function(width, height) {
        if (this._currentGridWidth == width && this._currentGridHeight == height) {
            return;
        }
        this._currentGridWidth = width;
        this._currentGridHeight = height;
        this.RENDERER_WIDTH = (width) * this.LETTER_WIDTH;
        this.RENDERER_HEIGHT = (height) * this.LETTER_HEIGHT;
        this.adjustToDeviceResolution();
    }
});



SpriteEffect = AbstractEffect.extend({
    beforeDone: function(tile, options) {
        tile.scale.x = tile.original.scale.x;
        tile.scale.y = tile.original.scale.y;
        tile.alpha = tile.original.alpha;
        tile.tint = tile.original.tint;
        tile.rotation = tile.original.rotation;
    },
    beforeBegin: function(tile, options) {},
});


TimerBarEffect = AbstractEffect.extend({
    beforeBegin: function(tile, options) {
        tile._originalX = tile.position.x;
    },
    applyEffect: function(tile, options, delta) {

        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        tile.children[0].position.x = -(tile.children[0].graphicsData[0].shape.width * factor);
        var square = tile.children[0].children[0];
        
        tile.children[0].children[0].rotation -= 0.025;
    },
});


LargifyEffect = SpriteEffect.extend({
    name: 'largify',
    beforeBegin: function(tile, options) {
        tile.scale.x = 0;
        tile.scale.y = 0;
    },
    applyEffect: function(tile, options, delta) {
        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        tile.scale.x = tile.original.scale.x * factor;
        tile.scale.y = tile.original.scale.y * factor;
    },
});
PawEffect = SpriteEffect.extend({
    name: 'paw',
    beforeBegin: function(tile, options) {
        tile.__pawOriginalY = tile.position.y;
    },
    applyEffect: function(tile, options, delta) {
        tile.position.y += delta / 15;
        if (tile.__pawOriginalY + tile.height*0.4 < tile.position.y) {
              tile.position.y = tile.__pawOriginalY;
        }
    },
    beforeDone: function(tile, options) {
        delete tile.__pawOriginalY;
        SpriteEffect.prototype.beforeDone.call(this, tile, options);
    }
});
AppearEffect = SpriteEffect.extend({
    name: 'appear',
    beforeBegin: function(tile, options) {
        tile.alpha = 0;
    },
    applyEffect: function(tile, options, delta) {
        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        tile.alpha = tile.original.alpha * factor;
    },
});
FlyToEffect = SpriteEffect.extend({
    name: 'flyto',
    DEFAULT_SPEED: 1,
    DEFAULT_SPIN: 0.5,
    beforeApply: function(tile, options) {
        options.speed = options.speed || this.DEFAULT_SPEED;
        options.spin = options.spin || this.DEFAULT_SPIN;
        options.fade = options.fade || 0;
        var a = options.x - tile.position.x;
        var b = options.y - tile.position.y;
        if (a == 0 && b == 0) {
            options.duration = 0;
            return;
        }
        var c = Math.sqrt(a * a + b * b);
        options.vx = (a / c) * options.speed;
        options.vy = (b / c) * options.speed;
        // in case it's orthogonal
        if (options.vy != 0) {
            options.duration = b / options.vy;
        } else {
            options.duration = a / options.vx;
        }
    },
    beforeBegin: function(tile, options) {
        SpriteEffect.prototype.beforeBegin.call(this, options);
        if (tile.position.x == options.x && tile.position.y == options.y) {
            options.timeLeft = 0;
        }
    },
    beforeDone: function(tile, options) {
        SpriteEffect.prototype.beforeDone.call(this, tile, options);
        tile.position.x = options.x;
        tile.position.y = options.y;
    },
    applyEffect: function(tile, options, delta) {
        if (tile.position.x != options.x || tile.position.y != options.y) {
            tile.position.x += options.vx * delta;
            tile.position.y += options.vy * delta;
            tile.rotation += options.spin;
            tile.alpha -= options.fade;
            
            var a = options.x - tile.position.x;
            var b = options.y - tile.position.y;
            // check if vector same sign if original, if not then we overshot (otherwise you get one flicker)
            if (!(options.vx < 0) == (options.x - tile.position.x < 0) || !(options.vy < 0) == (options.y - tile.position.y < 0)) {
                tile.position.x = options.x;
                tile.position.y = options.y;
            }
        }
    },
});
SmallifyEffect = SpriteEffect.extend({
    name: 'smallify',
    applyEffect: function(tile, options, delta) {
        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        factor = 1.0 - factor;
        tile.scale.x = tile.original.scale.x * factor;
        tile.scale.y = tile.original.scale.y * factor;
    },
});
DisperseEffect = SpriteEffect.extend({
    name: 'disperse',
    beforeDone: function(tile, options) {
        tile.alpha = tile.original.alpha;
    },
    applyEffect: function(tile, options, delta) {
        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        factor = 1.0 - factor;
        tile.alpha = tile.original.alpha * factor;
        tile.alpha = tile.original.alpha * factor;
    },
});
HighlightEffect = SpriteEffect.extend({
    name: 'highlight',
    initialize: function(options) {
        SpriteEffect.prototype.initialize.call(this, options);
        this.brightnessFilters = [];
        for (var i = 0; i < 12; i++) {
            this.brightnessFilters.push(new PIXI.filters.ColorMatrixFilter());
        }
    },
    brightnessFilterAssigner: 0,
    applyEffect: function(tile, options, delta) {
        var timePassed = options.duration - options.timeLeft;
        var factor = timePassed / options.duration;
        factor = (1.0 - factor) * Math.PI;
        var i = options.intensity ? options.intensity : 0.8;
        tile.filters[0].brightness(1 + Math.sin(factor) * i);
    },
    beforeBegin: function(tile, options) {
        var filter = this.brightnessFilters[(this.brightnessFilterAssigner++) % this.brightnessFilters.length];
        tile.filters = [filter];
    },
    beforeDone: function(tile, options) {
        tile.filters = null ;
    }
});

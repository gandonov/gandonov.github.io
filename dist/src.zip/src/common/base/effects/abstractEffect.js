AbstractEffect = Framework.BaseView.extend({
    
    _stampOriginal: function(tile) {
        if(tile.original){
            return;
        }
        tile.original = {};
        tile.original.scale = {};
        tile.original.scale.x = tile.scale.x;
        tile.original.scale.y = tile.scale.y;
        tile.original.alpha = tile.alpha;
        tile.original.tint = tile.tint;
        tile.original.rotation = tile.rotation;
    },


    initialize : function(options){
        Framework.BaseView.prototype.initialize.call(this, options);
         this.tiles = [];
    },

    beforeDone : function(tile, options){

    },
    // you can add stuff to options, ie store original scale
    beforeBegin : function(tile, options){

    },

    beforeApply : function(tile, options){

    },

    apply : function(tile, options){
        this._stampOriginal(tile);
        this.beforeApply(tile, options);
        options = options ? options : {};
        options.tile = tile;
        options.duration = options.duration || 2000;
        options.timeLeft = options.duration;
        options.offset = options.offset || 0;
        var duplicate = false;
        for(var i = this.tiles.length -1; i >= 0; i--){
            if(this.tiles[i].tile == tile){
                
                this.tiles[i] = options;
                duplicate = true;
            }
        }

        tile._effects = tile._effects || {};
        tile._effects[this.name] = true;

        
        this.beforeBegin(tile, options);
        if(!duplicate){
            this.tiles.push(options);
        }
    },

    applyEffect : function(tile, options, delta){

    },

    renderBatch : function(delta){
        for(var i = this.tiles.length -1; i >= 0; i--){
            var options = this.tiles[i];
            options.offset -= delta;    
            if(options.offset <= 0){
                if(options.timeLeft > 0){
                    this.applyEffect(options.tile, options, delta);
                    options.timeLeft-= delta;
                }else {   
                    delete options.tile._effects[this.name];
                    this.beforeDone(options.tile, options);
                    if(options.callback){
                        options.callback(options.tile);
                    }
                    this.tiles.splice(i, 1);

                }
            }
        }
    }

});

AboutView = Framework.BaseView.extend({
    template : templatePath + 'templates/tabs/AboutView.html',

    render : function(){
        if(!app.isBrowser){
            this.$('a').removeAttr('href');
        }
    }
});
'use strict';

var walk    = require('walk');
var fs = require("fs");
var files   = [];
var offsets = [];
// Walker options
console.log(process.argv);
var rootFolder = null;
var templatesFolder = null;
var filePath = "fp1911.html";
if(!process.argv[2]){
    console.log('usage: fpacker.js [index.html root folder] [templates folder] [optional: output path]');
    process.exit(1);
}else {
    rootFolder = process.argv[2];
    templatesFolder = process.argv[3];
    if(process.argv[4]){
        filePath = process.argv[4];
    }
}
process.chdir(rootFolder);
var walker  = walk.walk(templatesFolder, { followLinks: false });
var strBuffer = "";
walker.on('file', function (root, fileStats, next) {
    // Add this file to the list of files
    var rroot = root.replace(/\\/g,"/");
    var fpath = rroot + '/' + fileStats.name;
    fpath = fpath.replace(/\\/g,"/");
    fpath = fpath.replace(/\/\/+/g, '/');

    fs.readFile(fpath,"utf-8", function (err, buffer) {
        files.push(fpath);

        strBuffer += buffer;
        offsets.push(strBuffer.length);
        next();
    });



});

walker.on('end', function() {
    var walker2 = walk.walk("common\\templates", { followLinks: false });

    walker2.on('file', function (root, fileStats, next) {
        // Add this file to the list of files
        var rroot = root.replace(/\\/g,"/");
        var fpath = rroot + '/' + fileStats.name;
        fpath = fpath.replace(/\\/g,"/");
        fpath = fpath.replace(/\/\/+/g, '/');

        fs.readFile(fpath,"utf-8", function (err, buffer) {
            files.push(fpath);

            strBuffer += buffer;
            offsets.push(strBuffer.length);
            next();
        });



    });

    walker2.on('end', function() {
        var result = "<!-- fudgepacker1911begin ";
        for(var i = 0, l = offsets.length; i < l; i++){
            result += offsets[i] + " " +files[i] + " ";
        }
        result += "fudgepacker1911end -->";
        var toWrite = strBuffer + result;
        toWrite = toWrite.replace('PLACEHOLDER_TO_BE_REPLACED_BY_FPACKER', new Date());
        fs.writeFile(filePath, toWrite, function(err) {
            if(err) {
                return console.log(err);
            }
            console.log("The file was saved!");
        });
    });

});

var lineReader = require('readline').createInterface({
    input: fs.createReadStream('index.html')
});
var jsBuffer = "";

if(fs.existsSync('total.js')){
    fs.unlinkSync('total.js');
}
fs.closeSync(fs.openSync('total.js', 'w'));

lineReader.on('line', function (line) {

    if(line.indexOf('.js') > 0 && line.indexOf('noadd') < 0){
        var src = line.substring(line.indexOf('"') + 1);
        src = src.substring(0,src.indexOf('"'));
        try {
            var contents = fs.readFileSync(src).toString();
            fs.appendFileSync('total.js', contents + "\n\n");

        }catch (e){
            console.log('error reading file : ' + src + ' ?');
        }
    }
});
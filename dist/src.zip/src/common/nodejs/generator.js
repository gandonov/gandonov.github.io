
var bTime = Date.now();

var showTime = function(){
    var nTime = Date.now();
    console.log("time took: " + (nTime - bTime));
    bTime = nTime;
}

var commonWords = require('./www/data/commonWords.json');
var dictionary = require('./www/data/dictionary.json');
showTime();

var PuzzleGenerator = require('./www/js/puzzleGenerator');

var puzzleGenerator = new PuzzleGenerator.PuzzleGenerator(function(){}, dictionary, commonWords);

var bitwise = require('bitwise');

showTime();


for(var i  = 0, l = 10; i < l; i++){
    var board = puzzleGenerator.getTimedBoard(7);
    console.log(board);
}

showTime();

//console.log(puzzleGenerator);

